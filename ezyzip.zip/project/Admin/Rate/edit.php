<?php
	session_start();
	include_once('../connection.php');

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$ExaminerWork = $_POST['ExaminerWork'];
		$programcatagery = $_POST['programcatagery'];
		$quentity = $_POST['quentity'];
		$rate = $_POST['rate'];
		$years =$_POST['years'];
		//$sql = "UPDATE program SET programcode = '$programcode', programname = '$programname', programcatagery = '$programcatagery', totalnosemister = '$totalnosemister',totalstudent='$totalstudent',programduaration='$programduaration'  WHERE id = '$id'";
           
		$sql="UPDATE `rate` SET ExaminerWork='$ExaminerWork',programcatagery='$programcatagery',quentity='$quentity',rate='$rate',years='$years' WHERE id = '$id'";
		//use for MySQLi OOP


		//$sql="UPDATE `program` SET `programcode` = '$programcode',`programname` = '$programname',`programcatagery` 
		//= '$programcatagery',`totalnosemister` = '$totalnosemister',`programduaration` = '$programduaration' WHERE `program`.`id` = &id;";
		if($conn->query($sql)){
		echo "Member updated successfully";
		}
		
		else{
			echo"Something went wrong in updating member";
		}
	}
	else{
	echo"Select member to edit first";
	}

	header('location: index.php');

?>