<?php
	session_start();
	include_once('../connection.php');

	if(isset($_POST['add'])){
		
		$ExaminerWork  = $_POST['ExaminerWork'];
		$programcatagery = $_POST['programcatagery'];
		$quentity = $_POST['quentity'];
		$rate = $_POST['rate'];
		$years =$_POST['years'];
		
		//$sql = "INSERT INTO program (programcode, programname, programcatagery,totalnosemister,programduaration)
		// VALUES ('$programcode', '$programname', '$programcatagery','$totalnosemister','$programduaration')";


		$sql="INSERT INTO rate (ExaminerWork,programcatagery,quentity,rate,years)
		 VALUES ( '$ExaminerWork','$programcatagery', '$quentity', '$rate', '$years')";
		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Rate added successfully';
		}
		

		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: index.php');
?>
