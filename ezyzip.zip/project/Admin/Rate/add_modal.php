<!-- Add New -->
<div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Add New Rate</h4></center>
            </div>

            <div class="modal-body">
			<div class="container-fluid">

			<form method="POST" action="add.php">




			

			<div class="row form-group">
					
					
				</div>

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label"> Work:</label>
					</div>
					<div class="col-sm-10">

                    <select name="ExaminerWork" class="form-control" id="ExaminerWork" Required>
                        <option value="">SELECT EXAMINER WORK</option>
						<?php 
    $query ="SELECT * FROM examremu";
    $result = mysqli_query($conn,$query);
        while($row=mysqli_fetch_array($result)){
			?>
    <option value="<?php echo $row['ExaminerWork']; ?>" ><?php echo $row['ExaminerWork']; ?> </option>
   <?php
    }
    ?>
</select> 
                        
                
				<!--		<input type="text" placeholder="Enter new work "class="form-control" name="work" required autocomplete="off" Arequired>___-->
			</div>
				</div>

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">SElect UG/PG :</label>
					</div>
					<div class="col-sm-10">
						<select name="programcatagery" id="programcatagery" required class="form-control">
						<option value="">SELECT</option>
							<option value="POST_GRADUATION">POST GRADUATION</option>
							<option value="UNDER_GRADUATION">UNDER GRADUATION</option>
						</select>
					<!--	<input type="text" placeholder="Enter ug pg" class="form-control" name="ug_pg" required autocomplete="off">-->
					</div>
				</div>

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Quentity:</label>
					</div> 
					<div class="col-sm-10">
					
					
						<input type="number" placeholder=" Enter Quentity of Student/Set/Book/Day/Shift" class="form-control" name="quentity" autocomplete="off" >
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Rate :</label>
					</div>
					<div class="col-sm-10">
						<input type="number" placeholder="Enter A rate per Student/Set/Book/Day/Shift" class="form-control" name="rate" autocomplete="off" required>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Year:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Enter Year" class="form-control" name="years" autocomplete="off" required>
					</div>
				</div>
				
				
   
            </div> <!-- //container-fluid -->
			</div> <!-- // Body -->

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel
                </button>

                <button type="submit" name="add" class="btn btn-primary">
                	<span class="glyphicon glyphicon-floppy-disk"></span> Save</a>

			    </form>
            </div>

        </div>
    </div>
</div>
<script>
                         var select_box_element = document.querySelector('#programcode');
  
  dselect(select_box_element, {
      search: true
  });





                    </script>