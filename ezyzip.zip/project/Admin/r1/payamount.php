
<?php
		include_once('../connection.php');

	if(isset($_POST['add'])){
	    $id = $_POST['id'];
		$PayStatus1 = $_POST['PayStatus'];
		$PayStatus3="RETURN";  
		$PayStatus4="PAID";  
			 if(trim($PayStatus1)==$PayStatus3)		 
			 {   

				if(trim($PayStatus1)==$PayStatus3){

					$PayStatus=$PayStatus4;
				       }else{

						$PayStatus=$PayStatus3;
					   }
				$sql=" UPDATE workallotement SET 
				PayStatus='$PayStatus' WHERE id = '$id'";
			  }
			  else{
				header('location: index.php');
			  }
	
if($sql){

	echo"<script> alert('Paymentv Successfull') </script>";
	
	echo"<script> document location='index.php'; </script>";
				}
				else{
					echo"<script> alert('Somthing went wrong to Payment') </script>";
				}
		if($conn->query($sql)){


		
		}
	
		
		else{
			
		}
	}
	else{
		
	}

	header('location: index.php');
?>