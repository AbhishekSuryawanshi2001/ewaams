<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    
    session_unset();
    session_write_close();
    $url = "../Admin/index.php";
    header("Location: $url");
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Allocation </title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../datatable/dataTable.bootstrap.min.css">
	<style>
		.height10{
			height:10px;
		}
		.mtop10{
			margin-top:10px;
		}
		.modal-label{
			position:relative;
			top:7px
		}
	</style>
</head>

<body style="align-items: left;" >
<div class="container">
	<h1 class="page-header text-center"> <b>Exam Work Allotment </b></h1>

	<div class="row">
	

			<div class="row">
		
			<form method="POST" action="index.php">
<?php   
	include_once('../connection.php');
	 
	?>
	<center>
<select class="col-sm-10" name="fullname" required style=" height:40px; width: 400;">
<option value="" >Select Examiner</option>
<?php 
$query ="SELECT * FROM members";
$result = mysqli_query($conn,$query);
while($row=mysqli_fetch_array($result)){
?>
<option value="<?php echo $row['fullname'];?>" ><?php echo $row['fullname']; ?> </option>
<?php
}
?>
</select> 
 <br>
<br>
<br>
<br>
<div class="row">
	</div>
	
<div class="row">
<button type="submit" name="add" class="btn btn-primary" style=" height:40px; width: 100;">
<span class="glyphicon glyphicon-floppy-disk"></span> Show Examiner</a> </button>
</div>
</center>
</form>
<div class="row">
				<table id="myTable" class="table table-bordered table-striped">
					<thead>
					<th>AID</th>
						<th> Name</th>
						<th>Examiner Work</th>
						<th> Program  </th>
						<th>Semister</th>
						<th>Course/Subject </th>
						 <th>Exam Session</th>
						<th>Exam Year</th>
						<th> Rate</th>
						<th>Quntity</th>
						<th> Date Of Work Start</th>
						<th> Date Of Work End</th>
					     <th>Amount</th>
					     <th>Payment Status</th>
					     <th>Work Return</th>
					      <th>Pay</th>
                           </thead>
				            	<tbody>
					              <?php 
                                           $fullname=$_POST['fullname'];
                                                    ?>
						<?php
							include_once('../connection.php');
							$rerun1="NO_RETURN";
							$sql = "SELECT * FROM workallotement WHERE fullname = '$fullname'";
	//use for MySQLi-OOP
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
		<td>".$row['id']."</td>
		<td>".$row['fullname']."</td>
		<td>".$row['ExaminerWork']."</td>
		<td>".$row['programcode']."</td>
		<td>".$row['Exam']."</td>
		<td>".$row['Course_Subject_code']."</td>
		<td>".$row['Examsession']."</td>
		<td>".$row['ExamYear']."</td>
		<td>".$row['rateWork']."</td>
		<td>".$row['Quntity']."</td>
		<td>".$row['startDate']."</td>
		<td>".$row['lastDate']."</td>
		<td>".$row['amount']."</td>
		<td>".$row['PayStatus']."</td>
	       <td>			
			<a href='#Return_".$row['id']."' class='btn btn-info btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-edit'></span>Returan</a>
			</td> 
		     <td>
			<a href='#Allo_".$row['id']."' class='btn btn-warning btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-edit'></span>Pay</a>
			</td>	
		</tr>";
		include('edit_delete_modal.php');
	}		
		?>
		</tbody>
				</table>
          			</div>
		</div>
	</div>
</div>
<script src="../jquery/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../datatable/jquery.dataTables.min.js"></script>
<script src="../datatable/dataTable.bootstrap.min.js"></script>
<!-- generate datatable on our table -->
<script>
$(document).ready(function(){
	//inialize datatable
    $('#myTable').DataTable();

    //hide alert
    $(document).on('click', '.close', function(){
    	$('.alert').hide();
    })
});
</script>
<script>

</script>
</body>
</html>
                                        