
<?php
	include_once('../connection.php');

	if(isset($_POST['add'])){
	    $id = $_POST['id'];
        $Quntity = $_POST['Quntity'];
        $rateWork = $_POST['rateWork'];
        $amount1=$Quntity*$rateWork;
        $ExaminerWork = $_POST['ExaminerWork'];
		$PayStatus1=$_POST['PayStatus']; 
		$ExaminerWork1="Answer_Book_Valuation";

		$rerun1="NO_RETURN";

		if(trim($PayStatus1)==$rerun1)		 
		{
		
			if ((trim($ExaminerWork)==$ExaminerWork1)&&($amount1<100))	
			$amount=100;
		  else
			$amount=$amount1;
		 
			
				 $PayStatus2="NO_RETURN";
				 $PayStatus3="RETURN";  
					  if(trim($PayStatus1)==$PayStatus2)		 
					  {
						 $PayStatus=$PayStatus3;  
					   }
					   else{
						 $PayStatus=$PayStatus2;  
					   }
		  
	 $sql=" UPDATE workallotement SET 
	   Quntity='$Quntity',amount='$amount',PayStatus='$PayStatus' WHERE id = '$id'";
			
		 }
		 else{
			
	header('location: index.php');
	
		   
		 }
	
if($sql){

	echo"<script> alert('Return  Successfull ') </script>";
	
	echo"<script> document location='index.php'; </script>";
				}
				else{
					echo"<script> alert('Somthing went wrong to Get Return') </script>";
					echo"<script> document location='index.php'; </script>";
				}
		if($conn->query($sql)){
		}
		else{
			
		}
	}
	else{
		
	}

	header('location: index.php');
?>