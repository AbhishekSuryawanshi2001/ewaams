<?php
	include_once('../r1/connection.php');
$program_id =  $_POST['program_data'];
//$program_id ="MCA2020";
$program = "SELECT programcatagery FROM program WHERE programcode ='$program_id';";

$query = mysqli_query($conn, $program);
// $output="";

while ($p1 = mysqli_fetch_assoc($query)) {
    $output .= '<option value="' . $p1['programcatagery'] . '">' . $p1['programcatagery'] .'</option>';
}
echo $output;