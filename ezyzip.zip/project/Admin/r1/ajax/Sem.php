<?php
include_once('../r1/connection.php');
$program_id =  $_POST['program_data'];
//$program_id ="MCA2020";
$program = "SELECT distinct Exam FROM course_subject WHERE programcode ='$program_id';";

$query = mysqli_query($conn, $program);
// $output="";
$output = '<option value="">Select SEM</option>';
while ($p1 = mysqli_fetch_assoc($query)) {
    $output .= '<option value="' . $p1['Exam'] . '">' . $p1['Exam'] .'</option>';
}
echo $output;
