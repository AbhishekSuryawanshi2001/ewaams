
<!------ Allo---->
<div class="modal fade" id="Allo_<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Allotment Configration </h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="payamount.php">
			<input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
				<div class="row form-group">
            
               <div class="col-sm-15">
                                         <label class="control-label modal-label">The Aamount is Paid Then Click Yes </label>
                                    </div> 

                                               <div class="col-sm-2">
                                         <label class="control-label modal-label">Yes</label>
                                    </div>
                          <div class="col-sm-2">
                             <input type="radio" class="form-control" name="PayStatus" id="PAID" value="PAID">
                                                                              </div>
                                               <div class="col-sm-2">
                                         <label class="control-label modal-label">NO</label>
                                    </div>
                          <div class="col-sm-2">
                             <input type="radio" class="form-control" name="PayStatus"id="NOT_PAID" value="NOT_PAID" checked >
                                  
                                                                              </div>

                                <input type="hidden" class="form-control" id="PayStatus" name="PayStatus" value="<?php echo $row['PayStatus']; ?>">
                                                                              

				</div>
                <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="add" class="btn btn-success"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>


            </div>
			</div>

		
        

        </div>
    </div>
</div>


<!-- Return--->

<div class="modal fade" id="Return_<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">

	
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Allotment Configration </h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="Return.php">
			<input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
				<div class="row form-group">
            
            
				<div class="col-sm-4">
						<label class="control-label modal-label">Alloted Quntity:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" readonly  name="Quntity1"   class="form-control" value="<?php echo $row['Quntity']; ?>">
					</div>
                    <div class="col-sm-4">
						<label class="control-label modal-label">Rates:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" readonly name="rateWork" value="<?php echo $row['rateWork']; ?>">
					</div>
					<div class="col-sm-4">
						<label class="control-label modal-label">Return Quntity:</label>
					</div>
					<div class="col-sm-10">
						<input type="number" class="form-control" name="Quntity">
					</div>       
                    <div class="col-sm-4">
						<label class="control-label modal-label">Work:</label>
					</div>            
					<div class="col-sm-10">
						<input type=""  class="form-control" name="ExaminerWork" value="<?php echo $row['ExaminerWork']; ?>">
					</div>
					<div class="col-sm-10">
						<input type="hidden" class="form-control" name="PayStatus" value="<?php echo $row['PayStatus']; ?>">
					</div>
                    <div class="col-sm-2">
				</div>
                <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="add" class="btn btn-success"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>
            </div>
           </div>

        </div>
    </div>
</div>
