<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    
    session_unset();
    session_write_close();
    $url = "../index.php";
    header("Location: $url");
}

?>

<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="style.css">
      <style>

         table,th,td{
            border:1px solid black;
             border-collapse:collapse;
         }
         marquee{

            text-transform:uppercase ;
            color:brown;
         }
      </style>
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Home page</title> 
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="images/" alt="">
            </div>

            <span class="logo_name">EWAMS</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="#">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dahsboard</span>
                </a></li>
                <li><a href="Examiner\index.php">
                    <i class="uil uil-files-landscapes"></i>
                    <span class="link-name">Examiner</span>
                </a></li>
                <li><a href="Program\index.php">
                    <i class="uil uil-chart"></i>
                    <span class="link-name">Program</span>
                </a></li>
                <li><a href="course_subject/index.php">
                    <i class="uil uil-chart"></i>
                    <span class="link-name">Course</span>
                </a></li>
          
                <!--<li><a href="course_subject/selectprogramvisececourse.php">
                    <i class="uil uil-chart"></i>
                    <span class="link-name"> Course Program Wises</span>
                </a></li>  --->
                <li><a href="allo\index.php">
                    <i class="uil uil-chart"></i>
                    <span class="link-name">Workallotement</span>
                </a></li>
                <li><a href="displayalldata.php">
                    <i class="uil uil-chart"></i>
                    <span class="link-name">All Data</span>
                </a></li>
                <li><a href="Rate\index.php">
                    <i class="uil uil-chart"></i>
                    <span class="link-name">Add Rate</span> 
                </a></li>
                <li><a href="examinationwork\index.php">
                    <i class="uil uil-chart"></i>
                    <span class="link-name">Add Work</span> 
                </a></li>
            </ul>

        <br/><br/><br/><br/><br/>
            <ul class="logout-mode">
              <!--  <li><a href="">
                   
                    <i class="uil uil-signout"></i>
                    <span class="link-name">Logout</span>
                </a></li> -->

                <li class="mode">
                    <a href="#">
                        <i class="uil uil-moon"></i>
                    <span class="link-name">Dark Mode</span>
                </a>

                <div class="mode-toggle">
                  <span class="switch"></span>
                </div>
            </li> 
            </ul>
        </div>
    </nav>

    <section class="dashboard">
    <a href="" target="_blank"><img src="images/banner3-2.png" alt="" height="120px" width="1450px" ></a><br><hr>

        <div class="dash-content">
            <div class="overview">
                
                <div class="boxes">
                    <div class="box box1">
                        <i class="uil uil-chart"></i>
                        <span class="text">Total Examiner</span>
                        <?php   
							 include_once('connection.php');
							 
							?>
                       
                        <?php 
                              $query ="SELECT Eid FROM members";
                              $num=0;
                               $result = mysqli_query($conn,$query);
                               while($row=mysqli_fetch_array($result)){
                                $num++;
                               }
			                 ?>
                        <span class="number"><?php  echo $num; ?></span>
                    </div>
                    <div class="box box2">
                    
                       <i class="uil uil-chart"></i>
                        <span class="text"><a href="Program\index.php">
                        Total Programs </a></span>     
                       <?php   
							 include_once('connection.php');
							 
							?>
                       
                        <?php 
                              $query ="SELECT id FROM program";
                              $num=0;
                               $result = mysqli_query($conn,$query);
                               while($row=mysqli_fetch_array($result)){
                                $num++;
                               }
			                 ?>
                        <span class="number"><?php  echo $num; ?>
                             </span>
                     
                    </div>
                    <div class="box box3">
                        <i class="uil uil-chart"></i>
                        <?php   
							 include_once('connection.php');
							 
							?>
                       
                        <?php 
                              $query ="SELECT CSid FROM course_subject";
                              $num=0;
                               $result = mysqli_query($conn,$query);
                               while($row=mysqli_fetch_array($result)){
                                $num++;
                               }
			                 ?>
                        <span class="text">Total Courses</span>
                        <span class="number"><?php  echo $num; ?></span>
                            </div>

                </div>
            
            <div class="dash-content">
            <div class="overview">
                
                <div class="boxes">
                    <div class="box box1">
                        <i class="uil uil-chart"></i>
                        <span class="text">Total Entry Of Rate</span>
                        <?php   
							 include_once('connection.php');
							 
							?>
                       
                        <?php 
                              $query ="SELECT id FROM rate";
                              $num=0;
                               $result = mysqli_query($conn,$query);
                               while($row=mysqli_fetch_array($result)){
                                $num++;
                               }
			                 ?>
                        <span class="number"><?php  echo $num; ?></span>
                    </div>
                    <div class="box box2">
                       <i class="uil uil-chart"></i>
                        <span class="text">Total Entry Of Exam Work</span>
                       <?php   
							 include_once('connection.php');
							 
							?>
                       
                        <?php 
                              $query ="SELECT id FROM examremu";
                              $num=0;
                               $result = mysqli_query($conn,$query);
                               while($row=mysqli_fetch_array($result)){
                                $num++;
                               }
			                 ?>
                        <span class="number"><?php  echo $num; ?>
                             </span>
                    </div>
                    <div class="box box3">
                        <i class="uil uil-chart">
                        <span class="text"></span>
                        </i>
                        <?php   
							 include_once('connection.php');
							 
							?>
                       
                        <?php 
                              $query ="SELECT Aid FROM workallotement";
                              $num=0;
                               $result = mysqli_query($conn,$query);
                               while($row=mysqli_fetch_array($result)){
                                $num++;
                               }
			                 ?>
                        <span class="text"> Total Entry of Exam Work Allotment</span>
                        <span class="number"><?php  echo $num; ?></span>
                    </div>
                    <hr>



                </div>
                
            </div>

   

                        </div>
        </div>
    </section>

    <script src="script.js"></script>
</body>
</html>