<?php
	session_start();
?>
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
 
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}
   ?>
<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->

      <style>

         table,th,td{
            border:1px solid black;
             border-collapse:collapse;
         }
         marquee{

            text-transform:uppercase ;
            color:brown;
         }
      </style>
    
    
    <title>All Allotement Data</title> 
</head>
<body>
   
 
                  </div>     
                           <!-- Work Allotement--> 
                       <legend></legend>
                       <marquee behavior="" direction=""> <h2>All Work Allotement Information</h2></marquee>        
                    <br><br>
                       <div class="activity" >

                       <table  width="100%" bgcolor="#FFF8DC">
					<thead>
						<th>AID</th>
						<th> Name</th>
						<th>Examiner Work</th>
						<th> Program  </th>
						<th>Semister</th>
						<th>Course/Subject </th>
						
					    
						 <th>Exam Session</th>
						<th>Exam Year</th>
					
						<th>Quntity</th>
						<th> Rate</th>
						<th> Date Of Work Start</th>
						<th> Date Of Work End</th>
		
					  <th>Amount</th>
					</thead>
					<tbody>
						<?php
							include_once('connection.php');
							$sql = "SELECT * FROM workallotement";
							

	//use for MySQLi-OOP
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
			<td>".$row['id']."</td>
			<td>".$row['fullname']."</td>
			<td>".$row['ExaminerWork']."</td>
			<td>".$row['programcode']."</td>
			<td>".$row['Exam']."</td>
			<td>".$row['Course_Subject_code']."</td>
			<td>".$row['Examsession']."</td>
			<td>".$row['ExamYear']."</td>
			
			
			<td>".$row['Quntity']."</td>
			<td>".$row['rateWork']."</td>
			<td>".$row['startDate']."</td>
			<td>".$row['lastDate']."</td>
        
				<td>".$row['amount']."</td>
			
			
		</tr>";
	
	}
         	?>

					</tbody>
				</table>
   

                        </div>
                           


            </div>
        </div>
    </section>

    <script src="script.js"></script>
</body>
</html>