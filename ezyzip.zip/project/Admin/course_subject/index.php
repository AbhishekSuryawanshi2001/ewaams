<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Course Entry Form </title>
	<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../datatable/dataTable.bootstrap.min.css">
	<style>
		.height10{
			height:10px;
		}
		.mtop10{
			margin-top:10px;
		}
		.modal-label{
			position:relative;
			top:7px
		}
	</style>
</head>

<body>
<div class="container">
	<h1 class="page-header text-center"> <b>Course/Subject Entry Form </b></h1>

	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">

			<div class="row">
			<?php
				if(isset($_SESSION['error'])){
					echo
					"
					<div class='alert alert-danger text-center'>
						<button class='close'>&times;</button>
						".$_SESSION['error']."
					</div>
					";
					unset($_SESSION['error']);
				}
				if(isset($_SESSION['success'])){
					echo
					"
					<div class='alert alert-success text-center'>
						<button class='close'>&times;</button>
						".$_SESSION['success']."
					</div>
					";
					unset($_SESSION['success']);
				}
			?>
			</div>

			<div class="row">
				<a href="#addnew" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Add New Course</a>
				<a href="../report/ALLCOURSES.php" class="btn btn-success pull-right"><span class="glyphicon glyphicon-print"></span>ALL Course PDF</a>
			</div>

			<div class="height10"></div>
			
			<div class="row">
				<table id="myTable" class="table table-bordered table-striped" width="100">
					<thead>
						<th>CSID</th>
						<th>Course/Subject cod</th>
						<th> Course/Subject Name </th>
						<th>Program </th>
						<th>Course/Subject short Name</th>
				
					  <th>Course/Subject Type</th>
					 <th> Total No Units </th>
					 <th> Maximum Marks </th>
					 <th> Semister</th>
						<th>Edit</th>
						<th>Delete</th>
					</thead>
					<tbody>
						<?php
							include_once('../connection.php');
							$sql = "SELECT * FROM course_subject";
	//use for MySQLi-OOP
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
			<td>".$row['id']."</td>
			<td>".$row['Course_Subject_code']."</td>
			
			<td>".$row['Course_Subject_name']."</td>
			<td>".$row['programcode']."</td>
			<td>".$row['Course_Subject_shotname']."</td>
			
			<td>".$row['Course_Subject_type']."</td>
			
			<td>".$row['totalunit']."</td>
			
			<td>".$row['minimark']."</td>
			<td>".$row['Exam']."</td>
			<td>
				<a href='#edit_".$row['id']."' class='btn btn-success btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-edit'></span> Edit</a>
				 </td>
				<td>
				<a href='#delete_".$row['id']."' class='btn btn-danger btn-sm' data-toggle='modal'><span class='glyphicon glyphicon-trash'></span> Delete</a>
			</td>
		</tr>";
		include('edit_delete_modal.php');
	}


						?>

					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php include('add_modal.php') ?>

<script src="../jquery/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<script src="../datatable/jquery.dataTables.min.js"></script>
<script src="../datatable/dataTable.bootstrap.min.js"></script>





<!-- generate datatable on our table -->
<script>
$(document).ready(function(){
	//inialize datatable
    $('#myTable').DataTable();

    //hide alert
    $(document).on('click', '.close', function(){
    	$('.alert').hide();
    })
});
</script>

</body>





</html>
