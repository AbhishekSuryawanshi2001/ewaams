<!-- Add New -->
<div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Add New Course<h4></center>
            </div>

            <div class="modal-body">
			<div class="container-fluid">

			<form method="POST" action="add.php">

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Course Code:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Course/Subjectncode "class="form-control" name="Course_Subject_code" autocomplete="off" Arequired>
					</div>
				</div>

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Cours Full Name:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Course/Subject name" class="form-control" name="Course_Subject_name" required autocomplete="off">
					</div>
</div>

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Program Code:</label>
					</div> 
					<div class="col-sm-10">
					
					<?php   
							 include_once('connection.php');
							 
							?>
<select class="form-control" name="programcode" required >
    <option value="" >Program</option>
    <?php 
    $query ="SELECT * FROM program";
    $result = mysqli_query($conn,$query);
        while($row=mysqli_fetch_array($result)){
			?>
    <option value="<?php echo $row['programcode']; ?>" ><?php echo $row['programcode']; ?>:<?php echo $row['programname']; ?> </option>
   <?php
    }
    ?>
</select> </div>
				</div>

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Course short name:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Course /Subject_short name" class="form-control" name="Course_Subject_shotname" autocomplete="off" required>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Course type:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Course/Subject type" class="form-control" name="Course_Subject_type" autocomplete="off" required>
					</div>
				</div>
				 <!--   Add new elements-->
				 <div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Subject All Units:</label>
					</div>
					<div class="col-sm-10">
						<input type="number" placeholder="Course /Subject All Units" class="form-control" name="totalunit" autocomplete="off" required>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Maximum Mark:</label>
					</div>
					<div class="col-sm-10">
						<input type="number" placeholder="Course/Subject maximum Mark" class="form-control" name="minimark" autocomplete="off" required>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">select Semister</label>
					</div>
					<div class="col-sm-10">
					<select name="Exam" class="form-control" id="Exam" Required >
                        <option value="">Select semister for Subject</option>
                      <option value="SEMISTER_1">SEMISTER_1</option> 
                        <option value="SEMISTER_2">SEMISTER_2</option> 
                        <option value="SEMISTER_3">SEMISTER_3</option>
                        <option value="SEMISTER_4">SEMISTER_4</option> 
                        <option value="SEMISTER_5">SEMISTER_5</option> 
                        <option value="SEMISTER_6">SEMISTER_6</option>
                        <option value="SEMISTER_7">SEMISTER_7</option> 
                        <option value="SEMISTER_8">SEMISTER_8</option>
                    </select>
					</div>
				</div>
   
            </div> <!-- //container-fluid -->
			</div> <!-- // Body -->

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel
                </button>

                <button type="submit" name="add" class="btn btn-primary">
                	<span class="glyphicon glyphicon-floppy-disk"></span> Save</a>

			    </form>
            </div>

        </div>
    </div>
</div>
