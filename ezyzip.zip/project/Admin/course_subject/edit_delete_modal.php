<!-- Edit -->
<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Edit Course_Subject</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="edit.php">
				<input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
				<div class="row form-group">
					<div class="col-sm-2">
					
						<label class="control-label modal-label">Course/Subject Code:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Course_Subject_code" value="<?php echo $row['Course_Subject_code']; ?>">
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Course/Subject Name:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder=" " class="form-control" name="Course_Subject_name" value="<?php echo $row['Course_Subject_name']; ?>" autocomplete="off" required>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Program:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder=" " class="form-control" name="programcode" value="<?php echo $row['programcode']; ?>" autocomplete="off" required>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Course Shotname:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Course_Subject_shotname" value="<?php echo $row['Course_Subject_shotname']; ?>">
					</div>
				</div>

				
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label"> Course/Subject type:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="" class="form-control" name="Course_Subject_type" value="<?php echo $row['Course_Subject_type'];?>"autocomplete="off" required>
					</div>
				</div>

				<!--- trangection-->
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Total Unit:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="totalunit" value="<?php echo $row['totalunit']; ?>">
					</div>
				</div>

				
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Minimum Mark:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="" class="form-control" name="minimark" value="<?php echo $row['minimark'];?>"autocomplete="off" required>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Semister:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="" class="form-control" name="Exam" value="<?php echo $row['Exam'];?>"autocomplete="off" required>
					</div>
				</div>
            </div>
			</div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="edit" class="btn btn-success"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>

        </div>
    </div>
</div>

<!-- Delete -->
<div class="modal fade" id="delete_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Delete Member</h4></center>
            </div>
            <div class="modal-body">
            	<p class="text-center">Are you sure you want to Delete</p>
				<h2 class="text-center"><?php echo $row['Course_Subject_code'].' '.$row['Course_Subject_name']; ?></h2>
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Yes</a>
            </div>

        </div>
    </div>
</div>
