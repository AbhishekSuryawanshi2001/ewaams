<?php
	
	include_once('connection.php');

	if(isset($_POST['edit'])){
		$Course_Subject_code= $_POST['Course_Subject_code'];
		$Course_Subject_name=$_POST['Course_Subject_name'];
		$programcode=$_POST['programcode'];
		$Course_Subject_shotname=$_POST['Course_Subject_shotname'];
		$id =$_POST['id'];
		$Course_Subject_type=$_POST['Course_Subject_type'];
		$totalunit =$_POST['totalunit'];
		$minimark =$_POST['minimark'];
		$Exam =$_POST['Exam'];
		$Eid =$_POST['Eid'];

		//sql update course_subject
           
		$sql="UPDATE course_subject SET Course_Subject_code='$Course_Subject_code',Course_Subject_name='$Course_Subject_name',
		programcode='$programcode',Course_Subject_shotname='$Course_Subject_shotname',
		Course_Subject_type='$Course_Subject_type',totalunit='$totalunit',minimark='$minimark',Exam='$Exam' WHERE id ='$id'";
		//use for MySQLi OOP
		if($conn->query($sql)){
		echo"Member updated successfully";
		}
		
		else{
		echo"Something went wrong in updating member";
		}
	}
	else{
	   echo"Select member to edit first";
	}

	header('location: index.php');

?>