<style>

table,th,td{
   border:1px solid black;
	border-collapse:collapse;
}
</style>

<?php
	session_start();
	include_once('connection.php');

	if(isset($_POST['add'])){
	
		$programcode=$_POST['programcode'];
		
		
		$sql = "SELECT Course_Subject_code,Course_Subject_name , Course_Subject_shotname, Course_Subject_type
        FROM course_subject 
        WHERE programcode = '$programcode';";

		
		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'successfully';
		}
		
//erorr die
		else{
			$_SESSION['error'] = 'Something went wrong';
		}
	}
	
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}


?>






<!-- Add New -->

 <fieldset>


			<form method="POST" action="selectprogramvisececourse.php">

				

						<label class="control-label modal-label">Program Code:</label>
					

                    <?php   
						include_once('./connection.php');
							 
							?>
<select class="col-sm-10" name="programcode" required style=" height:40px; width: 400;">
    <option value="" >Program</option>
    <?php 
    $query ="SELECT * FROM program";
    $result = mysqli_query($conn,$query);
        while($row=mysqli_fetch_array($result)){
			?>
    <option value="<?php echo $row['programcode']; ?>" ><?php echo $row['programcode']; ?> </option>
   <?php
    }
    ?>
</select> 


                <button type="submit" name="add" class="btn btn-primary" style=" height:40px; width: 200;">
                	<span class="glyphicon glyphicon-floppy-disk"></span> Show Course</a> </button>

			    </form>
					
					<?php   
							 include_once('connection.php');
							 
							?>
				  </fieldset>
				  <br><br>
<table border="1px" width="100%" bgcolor="pink">
					<thead>
						<th>CSID</th>
						<th>Course/Subject code</th>
						<th> Course/Subject Name </th>
						<th>Program </th>
						<th>Course/Subject short Name</th>
				
					  <th>Course/Subject Type</th>
					 <th> Total No Units </th>
					 <th> Minimum Marks </th>
					 <th> Semister </th>
						
					</thead>
					<tbody>
						<?php
					include_once('../connection.php');
							$sql = "SELECT CSid,Course_Subject_code,Course_Subject_name,programcode,
							Course_Subject_shotname, Course_Subject_type,totalunit,minimark,Exam
                            FROM course_subject 
                            WHERE programcode = '$programcode';";
							

	//use for MySQLi-OOP
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
			<td>".$row['CSid']."</td>
			<td>".$row['Course_Subject_code']."</td>
			
			<td>".$row['Course_Subject_name']."</td>
			<td>".$row['programcode']."</td>
			<td>".$row['Course_Subject_shotname']."</td>
			
			<td>".$row['Course_Subject_type']."</td>
			
			<td>".$row['totalunit']."</td>
			
			<td>".$row['minimark']."</td>
			
			<td>".$row['Exam']."</td>
			
		</tr>";
	
	}


						?>

					</tbody>
				</table>