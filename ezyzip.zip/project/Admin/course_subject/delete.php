<?php

	include_once('connection.php');

	if(isset($_GET['id'])){
		//$CSid=$_POST['CSid'];

		$sql = "DELETE FROM course_subject WHERE id ='".$_GET['id']."'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			echo'Member deleted successfully';
		}
		
		else{
		echo'Something went wrong in deleting member';
		}
	}
	else{
		echo 'Select member to delete first';
	}

	header('location: index.php');
?>