<?php
	session_start();
?>
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
 
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}
   ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <br><br>
    <marquee behavior="" direction=""><h2>All Examiner Information </h2></marquee>
              <div class="activity">
                   <!-- Examiner  -->
              <table border="1px" width="100%" bgcolor="aqua">
                      <thead>
                          <th>ID</th>
                          <th>Full Name </th>
                          <th>Phone</th>
                          <th>Email</th>
                          <th>Address</th>
                          <th>Affilation</th>
                        <th> Experience </th>
                        <Th>Expertise</Th>
                          
                      </thead>
                      <tbody>
                          <?php
                           	include_once('../connection.php');
                              $sql = "SELECT * FROM members";
  
      //use for MySQLi-OOP
      $query = $conn->query($sql);
      while($row = $query->fetch_assoc()){
          echo
          "<tr>
              <td>".$row['id']."</td>
              <td>".$row['fullname']."</td>
              
              <td>".$row['phone']."</td>
              <td>".$row['email']."</td>
              <td>".$row['address']."</td>
              <td>".$row['Affi']."</td>
              <td>".$row['ExaminerExperience']."</td>
              <td>".$row['ExaminerExpertise']."</td>
  
              
          </tr>";
          
      }
  
  
                          ?>
  
                      </tbody>
                  </table>
                  <br><br>
                   <legend> </legend>  
                   <marquee behavior="" direction=""> <h2>All Program Information </h2></marquee>        
                      </div>
                  <div class="activity">
                   <!-- Program  -->
  
                   <table border="1px" width="100%"bgcolor="#FAEBD7">
                      <thead>
                          <th>ID</th>
                          <th>Program Code</th>
                          <th> Program Name </th>
                          <th>Program Catagery</th>
                          <th>Total Semister</th>
                  
                        <th>Program Duaration</th>
                       
                      
                      </thead>
                      <tbody>
                          <?php
                              include_once('connection.php');
                              $sql = "SELECT * FROM program";
  
      //use for MySQLi-OOP
      $query = $conn->query($sql);
      while($row = $query->fetch_assoc()){
          echo
          "<tr>
              <td>".$row['id']."</td>
              <td>".$row['programcode']."</td>
              
              <td>".$row['programname']."</td>
              <td>".$row['programcatagery']."</td>
              <td>".$row['totalnosemister']."</td>
              
              <td>".$row['programduaration']."</td>
              
  
              
          </tr>";
          
      }
  
  
                          ?>
  
                      </tbody>
                  </table>
  
                    </div>     
                             <!-- Course/Subject--> 
                         <legend></legend>
                         <marquee behavior="" direction=""> <h2>All Course/Subject Information </h2></marquee>        
                      <br><br>
                         <div class="activity" >
  
                         <table border="1px" width="100%" bgcolor="olive">
                      <thead>
                          <th>ID</th>
                          <th>Course/Subject code</th>
                          <th> Course/Subject Name </th>
                          <th>Program </th>
                          <th>Course/Subject short Name</th>
                  
                        <th>Course/Subject Type</th>
                      
                          <th> Semister</th>
                      </thead>
                      <tbody>
                          <?php
                              include_once('connection.php');
                              $sql = "SELECT * FROM course_subject";
                              
  
      //use for MySQLi-OOP
      $query = $conn->query($sql);
      while($row = $query->fetch_assoc()){
          echo
          "<tr>
              <td>".$row['id']."</td>
              <td>".$row['Course_Subject_code']."</td>
              
              <td>".$row['Course_Subject_name']."</td>
              <td>".$row['programcode']."</td>
              <td>".$row['Course_Subject_shotname']."</td>
              
              <td>".$row['Course_Subject_type']."</td>
              
          
              
              <td>".$row['Exam']."</td>
              
          </tr>";
      
      }
  
  
                          ?>
  
                      </tbody>
                  </table>
  
  
                         </div>
                      
          
      
  
                    </div>     
                             <!-- Work Allotement--> 
                         <legend></legend>
                         <marquee behavior="" direction=""> <h2>All Work Allotement Information</h2></marquee>        
                      <br><br>
                         <div class="activity" >
  
                         <table  border="1px" width="100%" bgcolor="#FFF8DC">
                      <thead>
                          <th>ID</th>
                          <th>Examiner Name</th>
                          <th> Program Code </th>
                          <th>Course/Subject Code </th>
                          <th> Date</th>
                  
                        <th>Exam </th>
                       
                          
                      </thead>
                      <tbody>
                          <?php
                              include_once('connection.php');
                              $sql = "SELECT * FROM workallotement	";
                              
  
      //use for MySQLi-OOP
      $query = $conn->query($sql);
      while($row = $query->fetch_assoc()){
          echo
          "<tr>
              <td>".$row['Aid']."</td>
              <td>".$row['fullname']."</td>
              
              <td>".$row['programcode']."</td>
              <td>".$row['Course_Subject_code']."</td>
              <td>".$row['EntryDate']."</td>
              
              <td>".$row['Exam']."</td>
              
  
              
          </tr>";
      
      }
  
  
                          ?>
  
                      </tbody>
                  </table>

</body>
</html>