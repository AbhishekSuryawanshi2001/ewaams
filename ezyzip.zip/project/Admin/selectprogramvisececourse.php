<?php
	session_start();
?>
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
 
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}
   ?>


<style>

table,th,td{
   border:1px solid black;
	border-collapse:collapse;
}
</style>

<?php
	session_start();
	include_once('connection.php');

	if(isset($_POST['add'])){
	
		$programcode=$_POST['programcode'];
		
		
		$sql = "SELECT Course_Subject_code,Course_Subject_name , Course_Subject_shotname, Course_Subject_type
        FROM course_subject 
        WHERE programcode = '$programcode';";

		
		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'successfully';
		}
		
//erorr die
		else{
			$_SESSION['error'] = 'Something went wrong';
		}
	}
	
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}


?>



<br><br>
<br><br>

<br><br>
<table border="1px" width="100%" bgcolor="pink">
					<thead>
						<th>ID</th>
						<th>Program </th>
						<th>Course/Subject code</th>
						<th> Course/Subject Name </th>
				
						<th>Course/Subject short Name</th>
						<th>Semester</th>
					  <th>Course/Subject Type</th>
					 <th> Total No Units </th>
					 <th> Maximum Marks </th>
						
					</thead>
					<tbody>
						<?php
							include_once('connection.php');
							$sql = "SELECT *
                            FROM course_subject 
                            WHERE programcode = '$programcode';";
							

	//use for MySQLi-OOP
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
			<td>".$row['id']."</td>
			<td>".$row['programcode']."</td>
			<td>".$row['Course_Subject_code']."</td>
			
			<td>".$row['Course_Subject_name']."</td>
		
			<td>".$row['Course_Subject_shotname']."</td>
			
			<td>".$row['Exam']."</td>
			<td>".$row['Course_Subject_type']."</td>
			
			<td>".$row['totalunit']."</td>
			
			<td>".$row['minimark']."</td>
			
		</tr>";
	}
?>
					</tbody>
				</table>
				<br><br> 
				<br><br> 

				<br><br> 
				<br><br> 

  <br><br> 
<form method="POST" action="selectprogramvisececourse.php">
<fieldset>
	 <center>  <h1> Select Program For Display its Courses/Subject</h1>

			<label class="control-label modal-label">Program Code:</label>
		

		<?php   
				 include_once('connection.php');
				 
				?>
<select class="col-sm-10" name="programcode" required style=" height:40px; width: 400;">
<option value="" >Program</option>
<?php 
$query ="SELECT * FROM program";
$result = mysqli_query($conn,$query);
while($row=mysqli_fetch_array($result)){
?>
<option value="<?php echo $row['programcode']; ?>" ><?php echo $row['programcode']; ?> <?php echo $row['programname']; ?> </option>
<?php
}
?>
</select> 


	<button type="submit" name="add" class="btn btn-primary" style=" height:40px; width: 200;">
		<span class="glyphicon glyphicon-floppy-disk"></span> Show Course</a> </button>

	</form>
		
		<?php   
				 include_once('connection.php');
				 
				?>

</center>
	  </fieldset>