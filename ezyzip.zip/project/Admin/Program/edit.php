<?php
	session_start();
	include_once('connection.php');

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$programcode  = $_POST['programcode'];
		$programname = $_POST['programname'];
		$programcatagery = $_POST['programcatagery'];
		$totalnosemister = $_POST['totalnosemister'];
		
		$programduaration=$_POST['programduaration'];
		//$sql = "UPDATE program SET programcode = '$programcode', programname = '$programname', programcatagery = '$programcatagery', totalnosemister = '$totalnosemister',totalstudent='$totalstudent',programduaration='$programduaration'  WHERE id = '$id'";
           
		$sql="UPDATE `program` SET programcode='$programcode',programname='$programname',programcatagery='$programcatagery',totalnosemister='$totalnosemister',programduaration='$programduaration' WHERE id = '$id'";
		//use for MySQLi OOP


		//$sql="UPDATE `program` SET `programcode` = '$programcode',`programname` = '$programname',`programcatagery` 
		//= '$programcatagery',`totalnosemister` = '$totalnosemister',`programduaration` = '$programduaration' WHERE `program`.`id` = &id;";
		if($conn->query($sql)){
		echo "Member updated successfully";
		}
		
		else{
			echo"Something went wrong in updating member";
		}
	}
	else{
	echo"Select member to edit first";
	}

	header('location: index.php');

?>