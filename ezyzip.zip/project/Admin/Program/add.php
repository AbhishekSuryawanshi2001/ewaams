<?php
	session_start();
	include_once('../connection.php');

	if(isset($_POST['add'])){
		$programcode  = $_POST['programcode'];
		$programname = $_POST['programname'];
		$programcatagery = $_POST['programcatagery'];
		$totalnosemister = $_POST['totalnosemister'];

		$programduaration=$_POST['programduaration'];
		
		$sql = "INSERT INTO program (programcode, programname, programcatagery,totalnosemister,programduaration) VALUES ('$programcode', '$programname', '$programcatagery','$totalnosemister','$programduaration')";
		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Program added successfully';
		}
		

		else{
			$_SESSION['error'] = 'Something went wrong while adding';
		}
	}
	
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: index.php');
?>
