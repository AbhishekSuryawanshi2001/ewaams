<!-- Add New -->
<div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Add New Program</h4></center>
            </div>

            <div class="modal-body">
			<div class="container-fluid">

			<form method="POST" action="add.php">

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Program Code/ID:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Program Code/ID "class="form-control" name="programcode" autocomplete="off" Arequired>
					</div>
				</div>

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Program Name:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Program Name" class="form-control" name="programname" required autocomplete="off">
					</div>
				</div>

				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Program Duarations:</label>
					</div> 
					<div class="col-sm-10">
					
						<select name="programduaration" id="programduaration" required class="form-control">
						<option value="">SELECT DUARATION OF PROGRAM</option>
							<option value="2_YEAR">2_YEAR</option>
							<option value="3_YEAR">3_YEAR</option>
							<option value="4_YEAR">4_YEAR</option>
							<option value="5_YEAR">5_YEAR</option>
						</select>

					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Program Catagery :</label>
					</div>

					<div class="col-sm-10">
						<select name="programcatagery" id="programcatagery" required class="form-control">
						<option value="">SELECT UG/PG</option>
						<option value="POST_GRADUATION">POST GRADUATION</option>
							<option value="UNDER_GRADUATION">UNDER GRADUATION</option>
						</select>
					 </div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Total Semester:</label>
					</div>
					<div class="col-sm-10">
					<select name="totalnosemister" id="totalnosemister" required class="form-control">
						<option value="">SELECT SEMESTER</option>
							<option value="4_SEMESTERE">4_SEMESTERE</option>
							<option value="6_SEMESTERE">6_SEMESTERE</option>
							<option value="8_SEMESTERE">8_SEMESTERE</option>
							<option value="10_SEMESTERE">10_SEMESTERE</option>
						</select>
					</div>
				</div>
				
				
   
            </div> <!-- //container-fluid -->
			</div> <!-- // Body -->

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel
                </button>

                <button type="submit" name="add" class="btn btn-primary">
                	<span class="glyphicon glyphicon-floppy-disk"></span> Save</a>

			    </form>
            </div>

        </div>
    </div>
</div>
