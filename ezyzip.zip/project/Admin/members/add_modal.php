<!-- Add New -->
<div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Add New Rate</h4></center>
            </div>

            <div class="modal-body">
			<div class="container-fluid">

			<form method="POST" action="add.php">


				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Full Name:</label>
					</div> 
					<div class="col-sm-10">
						<input type="text" placeholder=" Enter The Full Name " class="form-control" name="fullname" autocomplete="off" >
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Phone Number:</label>
					</div>
					<div class="col-sm-10">
						<input type="number" placeholder="Enter A Phone Number" class="form-control" name="phone" autocomplete="off" required>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Email:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Enter Email id" class="form-control" name="email" autocomplete="off" required>
					</div>
				</div><div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label"> Affilation:</label>
					</div> 
					<div class="col-sm-10">
						<input type="text" placeholder=" Enter where member can Work " class="form-control" name="Affi" autocomplete="off" >
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Exaperiance :</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Examiner Experience" class="form-control" name="ExaminerExperience" autocomplete="off" required>
					</div>
				</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Expritises :</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Examiner Expertise" class="form-control" name="ExaminerExpertise" autocomplete="off" required>
					</div>
				</div>
				
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Address :</label>
					</div>
					<div class="col-sm-10">
						<input type="text" placeholder="Exam member address" class="form-control" name="address" autocomplete="off" required>
					</div>
</div>
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">internal/eaxtranal:</label>
					</div>
					<div class="col-sm-10"> 
					<select id="internal_eaxtranal" class="form-control" name="internal_eaxtranal" autocomplete="off" required>
					<option value="">SELECT</option>
					<option value="internal">INTERNAL</option>
					<option value="External">EXTERNAL</option>

					</select>
					</div>
				</div>
   
            </div> <!-- //container-fluid -->
			</div> <!-- // Body -->

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel
                </button>

                <button type="submit" name="add" class="btn btn-primary">
                	<span class="glyphicon glyphicon-floppy-disk"></span> Save</a>

			    </form>
            </div>

        </div>
    </div>
</div>
<script>
                         var select_box_element = document.querySelector('#programcode');
  
  dselect(select_box_element, {
      search: true
  });





                    </script>