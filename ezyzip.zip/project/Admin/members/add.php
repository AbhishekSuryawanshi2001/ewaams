<?php

	include_once('connection.php');

	if(isset($_POST['add'])){
		$id=$_POST['id'];
		$fullname = $_POST['fullname'];
		$Affi = $_POST['Affi'];
		$address = $_POST['address'];
		$phone = $_POST['phone'];
		$ExaminerExperience =$_POST['ExaminerExperience'];
		$ExaminerExpertise=$_POST['ExaminerExpertise'];
		$email=$_POST['email'];
		$internal_eaxtranal=$_POST['internal_eaxtranal'];
		
		$sql = "INSERT INTO members (fullname, Affi, address,phone,ExaminerExperience,ExaminerExpertise,email,internal_eaxtranal)
		 VALUES ('$fullname', '$Affi', '$address','$phone','$ExaminerExperience','$ExaminerExpertise','$email','$internal_eaxtranal')";

		//use for MySQLi OOP
		if($conn->query($sql)){
			
		}
		

		else{
			
		}
	}
	
	else{
		
	}

	header('location: index.php');
?>

