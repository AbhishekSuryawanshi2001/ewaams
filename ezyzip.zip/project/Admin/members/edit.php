<?php
	session_start();
	include_once('../connection.php');

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$fullname = $_POST['fullname'];
		$Affi = $_POST['Affi'];
		$address = $_POST['address'];
		$phone = $_POST['phone'];
		$ExaminerExperience = $_POST['ExaminerExperience']; 
		 
		 $ExaminerExpertise = $_POST['ExaminerExpertise'];
		 $email = $_POST['email'];
		 $internal_eaxtranal=$_POST['internal_eaxtranal'];
		$sql = "UPDATE members SET fullname = '$fullname', Affi = '$Affi', address = '$address',
		 phone = '$phone',ExaminerExperience='$ExaminerExperience',ExaminerExpertise='$ExaminerExpertise',
		 email='$email',internal_eaxtranal='$internal_eaxtranal' 
		  WHERE id ='$id'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'Member updated successfully';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong in updating member';
		}
	}
	else{
		$_SESSION['error'] = 'Select member to edit first';
	}

	header('location: index.php');

?>