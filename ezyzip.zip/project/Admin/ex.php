<?php
	session_start();
?>
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}
?>
<style>
table,th,td{
   border:1px solid black;
	border-collapse:collapse;
}
h2{
	text-align: center;
	color: #DC143C;
}
fieldset{
background-color: beige;

}
</style>
<?php
	include_once('connection.php');
	if(isset($_POST['add'])){  
		$fullname=$_POST['fullname'];
       $sql="SELECT  * 
         FROM `workallotement` WHERE fullname = '$fullname';";
		if($conn->query($sql)){
		}
//erorr die
		else{	
		}
	}
?>
  <?php 
  $fullname=$_POST['fullname'];
  ?>

   <center><h1 > Select Examiner For Displying Its All Work Allotments </h1></center>
   <fieldset>
   <?php
							include_once('connection.php');
	$sql="SELECT fullname, sum(amount)AS 'amount' FROM `workallotement` WHERE fullname = '$fullname';";
							 
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
		<td><h2> Name:- ". $row['fullname']."</h2></td>
			<td><h2> Total Amount:- ". $row['amount']."</h2></td>
		</tr>";
	}

		?>
		  <?php
							include_once('connection.php');
	$sql="SELECT  sum(amount)AS 'amount' FROM `workallotement` WHERE fullname = '$fullname 'AND PayStatus='YES'; ";
							 
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
	
			<td><h2> Paid Amount:- ". $row['amount']."</h2></td>
		</tr>";
	}

		?>
		  <?php
							include_once('connection.php');
	$sql="SELECT  sum(amount)AS 'amount' FROM `workallotement` WHERE fullname = '$fullname 'AND PayStatus='NO'; ";
							 
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
	
			<td><h2> Balance Amount:- ". $row['amount']."</h2></td>
		</tr>";
	}

		?>

		 </fieldset>
	  <br><br>
<table border="1px" width="100%" bgcolor="DeepPink">
	
					<thead>
					
						<th>Aid</th>
						<th>program</th>
						<th> Course/Subject</th>
						<th>Semester</th>
					  <th>Exam Session</th>
					  <th> Exam Year</th>
                     <th> Examiner Work </th>
					 <th>Quntity</th>
					 <th>Date Work Start </th>
					 <th>Date Work End </th>
					 <th>Amount </th>
					 <th>Payment </th>
					</thead>
					<tbody>
						<?php
							include_once('connection.php');
	$sql="SELECT * FROM workallotement WHERE fullname = '$fullname';";
							 
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo

		"<tr>
		     <td>".$row['id']."</td>
			<td>".$row['programcode']."</td>
            <td>".$row['Course_Subject_code']."</td>
			<td>".$row['Exam']."</td>
			<td>".$row['Examsession']."</td>
			<td>".$row['ExamYear']."</td>
            <td>".$row['ExaminerWork']."</td>
			<td>".$row['Quntity']."</td>
			<td>".$row['startDate']."</td>
			<td>".$row['lastDate']."</td>
			<td>".$row['amount']."</td>
			<td>".$row['PayStatus']."</td>
		
		</tr>";
	}
			?>
					</tbody>
				</table>
				
          
	<br>
		<br><br> 
		
			

	

		<br>
		<br><br>
<center>

<form method="POST" action="ex.php">

	

			<label class="control-label modal-label">Examiner:</label>
		

		<?php   
				 include_once('connection.php');
				 
				?>
<select class="col-sm-10" name="fullname" required style=" height:40px; width: 400;">
<option value="" >Select Examiner</option>
<?php 
$query ="SELECT * FROM members";
$result = mysqli_query($conn,$query);
while($row=mysqli_fetch_array($result)){
?>
<option value="<?php echo $row['fullname']; ?>" ><?php echo $row['fullname']; ?> </option>
<?php
}
?>
</select> 
	<button type="submit" name="add" class="btn btn-primary" style=" height:40px; width: 200;">
		<span class="glyphicon glyphicon-floppy-disk"></span> Show Examiner</a> </button>

	</form>
		</center>