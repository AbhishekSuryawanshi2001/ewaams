<style>

table,th,td{
   border:1px solid black;
	border-collapse:collapse;
}
</style>

<?php
	session_start();
	include_once('connection.php');

	if(isset($_POST['add'])){
	
		$fullname=$_POST['fullname'];
		

       $sql="SELECT `fullname`, `programcode`, `Course_Subject_code`, 
        `EntryDate`, `Exam`, `Examsession`, `DateofExam`, `ExaminerWork`, `ExamYear`
         FROM `workallotement` WHERE fullname = '$fullname';";
		
		//$sql = "SELECT Course_Subject_code,Course_Subject_name , Course_Subject_shotname, Course_Subject_type
       // FROM course_subject 
       // WHERE fullname = '$fullname';";

		
		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = 'successfully';
		}
		
//erorr die
		else{
			$_SESSION['error'] = 'Something went wrong';
		}
	}
	
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}


?>






<!-- Add New -->

 <fieldset>


			<form method="POST" action="examinewiseallotment.php">

				

						<label class="control-label modal-label">Examiner:</label>
					

                    <?php   
							 include_once('connection.php');
							 
							?>
<select class="col-sm-10" name="fullname" required style=" height:40px; width: 400;">
    <option value="" >Select Examiner</option>
    <?php 
    $query ="SELECT * FROM members";
    $result = mysqli_query($conn,$query);
        while($row=mysqli_fetch_array($result)){
			?>
    <option value="<?php echo $row['fullname']; ?>" ><?php echo $row['fullname']; ?> </option>
   <?php
    }
    ?>
</select> 


                <button type="submit" name="add" class="btn btn-primary" style=" height:40px; width: 200;">
                	<span class="glyphicon glyphicon-floppy-disk"></span> Show Examiner</a> </button>

			    </form>
					
					<?php   
							 include_once('connection.php');
							 
							?>
				  </fieldset>
				  <br><br>
<table border="1px" width="100%" bgcolor="pink">
					<thead>
						<th>Examiner Name/th>
						<th>program Code</th>
						<th> Course/Subject Code </th>
						<th>Entry Date </th>
						<th>Exam</th>
				
					  <th>Exam Session</th>
					 <th> Date of Exam </th>
                     <th> Examiner Work </th>
					 <th> Exam Year</th>
						
					</thead>
					<tbody>
						<?php
							include_once('connection.php');
                            $sql="SELECT   `fullname`, `programcode`, `Course_Subject_code`, 
                            `EntryDate`, `Exam`, `Examsession`, `DateofExam`, `ExaminerWork`, `ExamYear` 
                            FROM `workallotement` WHERE fullname = '$fullname';";
                           // ORDER BY DESC
							//$sql = "SELECT id,Course_Subject_code,Course_Subject_name,programcode,Course_Subject_shotname, Course_Subject_type,totalunit,minimark
                           // FROM course_subject 
                           // WHERE programcode = '$programcode';";
							

	//use for MySQLi-OOP
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
			<td>".$row['fullname']."</td>
		
			<td>".$row['programcode']."</td>
            <td>".$row['Course_Subject_code']."</td>
			<td>".$row['EntryDate']."</td>
			
			<td>".$row['Exam']."</td>
			
			<td>".$row['Examsession']."</td>
			
			<td>".$row['DateofExam']."</td>
            <td>".$row['ExaminerWork']."</td>
			
			<td>".$row['ExamYear']."</td>
			
		</tr>";
	
	}


						?>

					</tbody>
				</table>