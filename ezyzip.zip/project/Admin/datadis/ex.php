<style>

table,th,td{
   border:1px solid black;
	border-collapse:collapse;
}
</style>

<?php

	include_once('connection.php');

	if(isset($_POST['add'])){
	  
		$fullname=$_POST['fullname'];
		

       $sql="SELECT  `fullname`, `programcode`, `Course_Subject_code`, `EntryDate`, 
	   `Exam`, `Examsession`, `ExaminerWork`, `ExamYear`, `Quntity` 
         FROM `workallotement` WHERE fullname = '$fullname';";
		
	
		if($conn->query($sql)){



            
			
		}
		
//erorr die
		else{
			
		}
	}
	
	


?>



   <center><h1> Select Examiner For Displying Its All Work Allotments </h1></center>


<!-- Add New -->


				  <br><br>
<table border="1px" width="100%" bgcolor="pink">
					<thead>
						<th>Aid</th>
						<th>Examiner Name</th>
						<th>program</th>
						<th> Course/Subject </th>
						
						<th>Semester</th>
				
					  <th>Exam Session</th>
					  <th> Exam Year</th>
                     <th> Examiner Work </th>
					 <th>Quntity</th>
					 <th>Entry Date </th>
					 <th>Amount </th>
					</thead>
					<tbody>
						<?php
							include_once('connection.php');
							$sql="SELECT  *
							  FROM `workallotement` WHERE fullname = '$fullname';";
							 
	$query = $conn->query($sql);
	while($row = $query->fetch_assoc()){
		echo
		"<tr>
		<td>".$row['Aid']."</td>
			<td>".$row['fullname']."</td>
		
			<td>".$row['programcode']."</td>
            <td>".$row['Course_Subject_code']."</td>
		
			<td>".$row['Exam']."</td>
			
			
			<td>".$row['Examsession']."</td>
			<td>".$row['ExamYear']."</td>
		
            <td>".$row['ExaminerWork']."</td>
			
			<td>".$row['Quntity']."</td>
			<td>".$row['EntryDate']."</td>
			<td>".$row['amount']."</td>
		</tr>";
	
	}


						?>

					</tbody>
				</table>
				
          <!-- From
		-->
		<br><br>
<center>
<fieldset>
<form method="POST" action="ex.php">

	

			<label class="control-label modal-label">Examiner:</label>
		

		<?php   
				 include_once('connection.php');
				 
				?>
<select class="col-sm-10" name="fullname" required style=" height:40px; width: 400;">
<option value="" >Select Examiner</option>
<?php 
$query ="SELECT * FROM members";
$result = mysqli_query($conn,$query);
while($row=mysqli_fetch_array($result)){
?>
<option value="<?php echo $row['fullname']; ?>" ><?php echo $row['fullname']; ?> </option>
<?php
}
?>
</select> 


	<button type="submit" name="add" class="btn btn-primary" style=" height:40px; width: 200;">
		<span class="glyphicon glyphicon-floppy-disk"></span> Show Examiner</a> </button>

	</form>
		
		<?php   
				 include_once('connection.php');
				 
				?>

	  </fieldset></center>