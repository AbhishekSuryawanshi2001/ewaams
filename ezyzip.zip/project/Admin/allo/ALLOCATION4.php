<?php
          $programcode = $_POST['programcode'];
          $programcatagery = $_POST['programcatagery'];
           $Exam = $_POST['Exam'];

         $Course_Subject_code = $_POST['Course_Subject_code'];
         $fullname=$_POST['fullname'];
		$Examsession = $_POST['Examsession'];
        $ExamYear = $_POST['ExamYear'];
        $ExaminerWork = $_POST['ExaminerWork'];
		$Quntity = $_POST['Quntity'];
	
		
        $name=$fullname;
      
?>
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
   
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
  
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
        <script src="library/bootstrap-5/bootstrap.bundle.min.js"></script>
        <script src="library/dselect.js"></script>
        <style>
    input{
        counter-reset: pink;
        font-size: larger;
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        text-size-adjust: auto;

    }
    fieldset{

        text-decoration: none;
        text-shadow: 0cm;
        text-transform: uppercase;
        overflow: hidden;
         color: red;
        box-shadow: 0cqb;
        border-color: rgb(165, 165, 22);
        background-color: beige;
        border: 10px solid dodgerblue;
    }
    body{
margin: 0;
padding: 0;
background-color:slateblue;
        border: 10px solid violet;
    }
    h1{
 background-color: aqua;
text-transform: uppercase;
color: gray;
text-decoration:saddlebrown;

        border: 10px solid orange;
    }
</style>
        <title>Examiner Work  Allocation</title>
    </head>
    <body onload="addDate()">
   
   <hr>
    <center> <h1> Examiner Work  Allocation </h1></center>
   
    <hr>

    <div class="container">
    <fieldset>
       <center>
    <form action="addAllo.php" method="POST"  name="Allocation">
    <br>
    <strong>Selected Progrm  </strong>

    <div class="col-md-4">
    <input type="text" name="programcode1" id="programcode1" value="<?php echo $programcode; ?>" required readonly>
      </div> 

      <strong>Selected </strong>
     <div class="col-md-4">
    <input type="text" name="programcatagery" id="programcatagery"  value="<?php echo $programcatagery; ?>"  required readonly>
    </div>     
    <strong> PROGRAM Sem  </strong>

<div class="col-md-4">
<input type="text" name="Exam" id="Exam" value="<?php echo $Exam; ?>" required readonly>
  </div> 

  <strong> Course/Subject  </strong>

<div class="col-md-4">
<input type="text" name="Course_Subject_code" id="Course_Subject_code" value="<?php echo $Course_Subject_code; ?>" required readonly>
  </div> 

 
  <strong> NAME  </strong>

<div class="col-md-4">
<input type="text" name="fullname" id="fullname" value="<?php echo $name;?>" required readonly>
  </div>  
  <strong>Selected exam seestion </strong>
 <div class="col-md-4">
<input type="text" name="Examsession" id="Examsession" value="<?php echo $Examsession; ?>" required readonly>
</div>



<strong>Selected YEAR </strong>
 <div class="col-md-4">
<input type="text" name="ExamYear" id="ExamiYear" value="<?php echo $ExamYear; ?>" required readonly>
</div> 
<strong>Selected exam exam work </strong>
 <div class="col-md-4">
<input type="text" name="ExaminerWork" id="ExaminerWork" value="<?php echo $ExaminerWork; ?>" required readonly>
</div>   
<strong>Selected Quantity </strong>
 <div class="col-md-4">
<input type="text" name="Quntity" id="Quntity" value="<?php echo $Quntity;?>" required readonly>
</div>
   

                 <strong>SELECTED RATE</strong>

           
        
<div class="col-md-4">
   
    <select name="rateWork" class="form-select" id="rateWork" required>
   
   <?php 
   $connect = new PDO("mysql:host=localhost;dbname=ewaams", "root", "");

  $query = "SELECT rate FROM rate WHERE ExaminerWork='$ExaminerWork' AND programcatagery='$programcatagery';";
   
   $result = $connect->query($query);
   foreach($result as $row)
   {
       echo '<option value="'.$row["rate"].' ">'.$row["rate"].'</option>';
   }
   ?>  
</select>
</div>



        <strong>Enter a Examiner  Working  Start Date </strong>
           
           
                <div class="col-md-4">
                    <input type="date" name="startDate" class="form-select" id="startDate" Required>
                      
                </div>

   <strong>Enter a Examiner  Working  Last Date </strong>
                
            
                <div class="col-md-4">
                    <input type="date" name="lastDate" class="form-select" id="lastDate" Required>
                      
                </div>
              <!--  <strong> Enter Date Of Allocation</strong>  _----->
            
           
                <div class="col-md-4">
                    <input type="text"  name="EntryDate" class="form-control" id="date" Required hidden >
                      
                </div>
        

              <!--  <strong> Enter Date Of Allocation</strong>  _----->
            
           
                
        
                    <hr>     
 <div class="col-md-8">
 <button class="btn btn-primary" name="add">
                            Allocation</button>
<input type="reset" class="btn btn-primary">
                    
                           
                             </div>
        <hr>
        </center>
        </fieldset>
        
        </form>

        </div>


    </body>
    <br>
    <br>
</html>


<!--
<script src="Allocation.js"></script>

<script type="text/javascript" src="Allocation.js"></script>
                    -->
                    <script>
     var box_element = document.querySelector('#fullname');

dselect(box_element, {
    search: true
});
var box_element = document.querySelector('#ExaminerWork');

dselect(box_element, {
    search: true
});


var box_element = document.querySelector('#Course_Subject_code');

dselect(box_element, {
    search: true
});

function addDate(){ 
    date = new Date(); 
    var month = date.getMonth()+1; 
    var day = date.getDate(); 
    var year = date.getFullYear(); 
  
    if (document.getElementById('date').value == ''){ 
        document.getElementById('date').value =  year+  '-' + month + '-' +day  ; 
    } 
    else{
        document.write('Problem in local date');
    }
}
</script>
     