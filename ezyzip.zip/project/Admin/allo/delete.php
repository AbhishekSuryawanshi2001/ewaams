<?php
	session_start();
	include_once('connection.inc.php');

	if(isset($_GET['id'])){
		$sql = "DELETE FROM workallotement  WHERE id = '".$_GET['id']."'";

		//use for MySQLi OOP
		if($conn->query($sql)){
			$_SESSION['success'] = '';
		}
		
		else{
			$_SESSION['error'] = 'Something went wrong in deleting ';
		}
	}
	else{
		$_SESSION['error'] = 'Select  to delete first';
	}

	header('location: index.php');
?>