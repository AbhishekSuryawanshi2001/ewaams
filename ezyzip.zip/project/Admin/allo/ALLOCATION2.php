<?php
  $programcode = $_POST['programcode'];

  
  $programcode1 = $programcode;
?>
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
   
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
  
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
        <script src="library/bootstrap-5/bootstrap.bundle.min.js"></script>
        <script src="library/dselect.js"></script>
        <style>
    input{
        counter-reset: pink;
        font-size: larger;
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        text-size-adjust: auto;

    }
    fieldset{

        text-decoration: none;
        text-shadow: 0cm;
        text-transform: uppercase;
        overflow: hidden;
         color: red;
        box-shadow: 0cqb;
        border-color: rgb(165, 165, 22);
        background-color: beige;
    }
    body{
margin: 0;
padding: 0;
background-color:cadetblue;
    }
    h1{
 background-color: aqua;
text-transform: uppercase;
color: brown;
text-decoration:saddlebrown;
    }
</style>
        <title>Examiner Work  Allocation</title>
    </head>
    <body onload="">
   
   <hr>
    <center> <h1> Examiner Work  Allocation </h1></center>
   
    <hr>

    <div class="container">
    <fieldset>
       <center>
    <form action="ALLOCATION3.php" method="POST"  name="seSelect">
    
    <br>    
    <strong> AUTO SELECTED PROGRAM </strong>
      <div class="col-md-6" style="text-align: center;" >
          <input type="text" name="programcode" id="programcode" value="<?php echo $programcode1; ?>" readonly>
          </div>

          <br>
    <strong>AUTO SELECTED PROGRAM CATAGERY </strong>
                <div class="col-md-4">
                    <select name="programcatagery" class="form-select" id="programcatagery" required>
                        <?php 
                        $connect = new PDO("mysql:host=localhost;dbname=ewaams", "root", "");

                       $query = "SELECT programcatagery
                       FROM program 
                       WHERE programcode = '$programcode'; ";
                        
                        $result = $connect->query($query);
                        foreach($result as $row)
                        {
                            echo '<option value="'.$row["programcatagery"].' ">'.$row["programcatagery"].'</option>';
                        }
                        ?>  
                    </select>

                </div>
        
    <br>
    <strong> SElect semister </strong>
                <div class="col-md-4">
                    <select name="Exam" class="form-select" id="Exam" required>
                        <option value="">Select semister</option>
                        <?php 
                        $connect = new PDO("mysql:host=localhost;dbname=ewaams", "root", "");

                       $query = "SELECT Exam 
                       FROM course_subject 
                       WHERE programcode = '$programcode'; ";
                        
                        $result = $connect->query($query);
                        foreach($result as $row)
                        {
                            echo '<option value="'.$row["Exam"].' ">'.$row["Exam"].'</option>';
                        }
                        ?>  
                    </select>

                </div>
                 <br><br><br><br><br><br><br><br><br>
                    <hr>     
 <div class="col-md-8">
 <button class="btn btn-primary" name="add">
                            Allocation</button>

                    
                           
                             </div>
        <hr>
        </center>
        </fieldset>
        
        </form>

        </div>
    </body>
</html>

<script>
     var box_element = document.querySelector('#Exam');

dselect(box_element, {
    search: true
});

</script>
<!--
<script src="Allocation.js"></script>

<script type="text/javascript" src="Allocation.js"></script>
_-->