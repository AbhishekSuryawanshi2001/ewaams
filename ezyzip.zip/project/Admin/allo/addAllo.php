<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
   
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>
<?php
	include_once('connection.php');

	if(isset($_POST['add'])){
	    $fullname = $_POST['fullname'];
		$programcode = $_POST['programcode1'];
		$Course_Subject_code = $_POST['Course_Subject_code'];
	
		$EntryDate = $_POST['EntryDate'];
	    $Exam = $_POST['Exam'];
// add New 
		$Examsession = $_POST['Examsession'];
	
		$ExaminerWork = $_POST['ExaminerWork'];
		$Quntity = $_POST['Quntity'];
	
		$ExamYear = $_POST['ExamYear'];
		$startDate = $_POST['startDate'];
		$lastDate = $_POST['lastDate'];
		$rateWork = $_POST['rateWork'];
		 

		$amount=$Quntity*$rateWork;
	
     $sql = "INSERT INTO workallotement (fullname,programcode,Course_Subject_code,EntryDate,Exam,Examsession,ExaminerWork,ExamYear,Quntity,startDate,lastDate,rateWork,amount ) VALUES 
	('$fullname','$programcode','$Course_Subject_code','$EntryDate','$Exam','$Examsession','$ExaminerWork','$ExamYear','$Quntity','$startDate','$lastDate','$rateWork','$amount' )";

if($sql){

	echo"<script> alert('You Have Successfull inserted the Examiner Allotment') </script>";
	
	echo"<script> document location='index.php'; </script>";
				}
				else{
					echo"<script> alert('Somthing went wrong to Add  Examiner Allotment') </script>";
				}
		if($conn->query($sql)){


		
		}
		///////////////

		//use for MySQLi Procedural
		// if(mysqli_query($conn, $sql)){
		// 	$_SESSION['success'] = 'Member added successfully';
		// }
		//////////////
		
		else{
			
		}
	}
	else{
		
	}

	header('location: index.php');
?>