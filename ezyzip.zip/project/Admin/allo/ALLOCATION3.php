<?php
  $programcode = $_POST['programcode'];


  
  $programcatagery=$_POST['programcatagery'];
  
  $Exam=$_POST['Exam'];
?>
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
   
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
  
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
        <script src="library/bootstrap-5/bootstrap.bundle.min.js"></script>
        <script src="library/dselect.js"></script>
        <style>
    input{
        counter-reset: pink;
        font-size: larger;
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        text-size-adjust: auto;

    }
    fieldset{

        text-decoration: none;
        text-shadow: 0cm;
        text-transform: uppercase;
        overflow: hidden;
         color: red;
        box-shadow: 0cqb;
        border-color: rgb(165, 165, 22);
        background-color: beige;
        border: 10px solid dodgerblue;
    }
    body{
margin: 0;
padding: 0;
background-color:slateblue;
        border: 10px solid violet;
    }
    h1{
 background-color: aqua;
text-transform: uppercase;
color: gray;
text-decoration:saddlebrown;

        border: 10px solid orange;
    }
</style>
        <title>Examiner Work  Allocation</title>
    </head>
    <body onload="addDate()">
   
   <hr>
    <center> <h1> Examiner Work  Allocation </h1></center>
   
    <hr>

    <div class="container">
    <fieldset>
       <center>
    <form action="ALLOCATION4.php" method="POST"  name="Allocation">


    
    <strong> PROGRAM  </strong>

<div class="col-md-4">
<input type="text" name="programcode" id="programcode" value="<?php echo $programcode; ?>" required readonly>
  </div> 
    <strong> PROGRAM  </strong>

    <div class="col-md-4">
    <input type="text" name="programcatagery" id="programcatagery" value="<?php echo $programcatagery; ?>" required readonly>
      </div> 

      <strong>Selected Semester </strong>
     <div class="col-md-4">
    <input type="text" name="Exam" id="Exam" value="<?php echo $Exam; ?>" required readonly>
    </div>


    <strong>Select Subject</strong>
           
           <div class="col-md-4">
               <select name="Course_Subject_code" class="form-select" id="Course_Subject_code" required>
                   <option value="">Select Subject</option>
                   <?php 
                   $connect = new PDO("mysql:host=localhost;dbname=ewaams", "root", "");

                  $query = "SELECT Course_Subject_code,Course_Subject_name
                  FROM course_subject 
                  WHERE programcode ='$programcode' AND Exam= '$Exam'; ";
                   
                   $result = $connect->query($query);
                   foreach($result as $row)
                   {
                       echo '<option value="'.$row["Course_Subject_code"].' ">'.$row["Course_Subject_code"].''.$row["Course_Subject_name"].'</option>';
                   }
                   ?>  
               </select>
           </div>

    <strong>Select  Examinr</strong>
           
           <div class="col-md-4">
               <select name="fullname" class="form-select" id="fullname" required>
                   <option value="">Select Examiner</option>
                   <?php 
                   $connect = new PDO("mysql:host=localhost;dbname=ewaams", "root", "");

                  $query = "SELECT fullname,phone
                  FROM  members ";
                   
                   $result = $connect->query($query);
                   foreach($result as $row)
                   {
                       echo '<option value="'.$row["fullname"].' ">'.$row["fullname"].''.$row["phone"].'</option>';
                   }
                   ?>  
               </select>
           </div>
               
        

        
            

           <strong>Select Session</strong>
            
        
          
           
                <div class="col-md-4">
                    <select name="Examsession" class="form-select" id="Exam" Required>
                        <option value="">Select Session</option>
                      <option value="SUMMER">SUMMER</option> 
                        <option value="WINTER">WINTER</option> 
                       
                        
                    </select>
                </div>
        
               
            <strong> SELECT EXAM YEAR</strong>
           
            
                <div class="col-md-4">
                    <select name="ExamYear" class="form-select" id="ExamYear" Required>
                        <option value="">SELECT YEAR</option>
                      <option value="2023">2023</option> 
                        <option value="2024">2024</option> 
                        <option value="2025">2025</option>
                        <option value="2026">2026</option> 
                        <option value="2027">2027</option> 
                        <option value="2028">2028</option>
                        <option value="2029">2029</option> 
                        <option value="2030">2030</option>
                    </select>
                </div>
        
             
<strong>SELECT EXAM WORK</strong>

           
        
                <div class="col-md-4">
                   
                    <select name="ExaminerWork" class="form-select" id="ExaminerWork" required>
                   <option value="">Select Exam Work</option>
                   <?php 
                   $connect = new PDO("mysql:host=localhost;dbname=ewaams", "root", "");

                  $query = "SELECT ExaminerWork
                  FROM  examremu ";
                   
                   $result = $connect->query($query);
                   foreach($result as $row)
                   {
                       echo '<option value="'.$row["ExaminerWork"].' ">'.$row["ExaminerWork"].'</option>';
                   }
                   ?>  
               </select>
                </div>
        
                 <strong>Enter Quantity Of Set/Student</strong>
           
            
                <div class="col-md-4">
                    <input type="number" name="Quntity"  placeholder="Enter a Quantity Of Sets Or Students" class="form-control" id="Quntity" Required>
                      
                </div>
        <!---- <strong>Enter Rate</strong>
           
           
                <div class="col-md-4">
                    <input type="number" name="rateWork" placeholder="Enter Rate of Work" class="form-control" id="rateWork" Required>
                      
                </div>  ---->
       
        

        
                    <hr>     
 <div class="col-md-8">
 <button class="btn btn-primary" name="add">
                            Allocation</button>
<input type="reset" class="btn btn-primary">
                    
                           
                             </div>
        <hr>
        </center>
        </fieldset>
        
        </form>

        </div>


    </body>
    <br>
    <br>
</html>


<!--
<script src="Allocation.js"></script>

<script type="text/javascript" src="Allocation.js"></script>
                    -->
                    <script>
     var box_element = document.querySelector('#fullname');

dselect(box_element, {
    search: true
});
var box_element = document.querySelector('#ExaminerWork');

dselect(box_element, {
    search: true
});


var box_element = document.querySelector('#Course_Subject_code');

dselect(box_element, {
    search: true
});

function addDate(){ 
    date = new Date(); 
    var month = date.getMonth()+1; 
    var day = date.getDate(); 
    var year = date.getFullYear(); 
  
    if (document.getElementById('date').value == ''){ 
        document.getElementById('date').value =  year+  '-' + month + '-' +day  ; 
    } 
    else{
        document.write('Problem in local date');
    }
}
</script>
    