<?php
	session_start();
	include_once('connection.inc.php');

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$fullname = $_POST['fullname'];
		$programcode = $_POST['programcode'];
		$Course_Subject_code = $_POST['Course_Subject_code'];
	

	    $Exam = $_POST['Exam'];
// add New 
		$Examsession = $_POST['Examsession'];
	
		$ExaminerWork = $_POST['ExaminerWork'];
		$Quntity = $_POST['Quntity'];
	
		$ExamYear = $_POST['ExamYear'];
		$startDate = $_POST['startDate'];
		$lastDate = $_POST['lastDate'];
		$rateWork = $_POST['rateWork'];
		 

		$amount=$Quntity*$rateWork;
		
		//$sql = "UPDATE program SET programcode = '$programcode', programname = '$programname', programcatagery = '$programcatagery', totalnosemister = '$totalnosemister',totalstudent='$totalstudent',programduaration='$programduaration'  WHERE id = '$id'";
           
		$sql=" UPDATE workallotement SET 
		fullname='$fullname',programcode='$programcode',Course_Subject_code='$Course_Subject_code',
		Exam='$Exam',Examsession='$Examsession',ExaminerWork='$ExaminerWork',ExamYear='$ExamYear',
		Quntity='$Quntity',
		startDate='$startDate',lastDate='$lastDate',rateWork='$rateWork',amount='$amount' WHERE id = '$id'";
		//use for MySQLi OOP


		//$sql="UPDATE `program` SET `programcode` = '$programcode',`programname` = '$programname',`programcatagery` 
		//= '$programcatagery',`totalnosemister` = '$totalnosemister',`programduaration` = '$programduaration' WHERE `program`.`id` = &id;";
		if($conn->query($sql)){
		echo " updated successfully";
		}
		
		else{
			echo"Something went wrong in updating";
		}
	}
	else{
	echo"Select to edit first";
	}

	header('location: index.php');

?>