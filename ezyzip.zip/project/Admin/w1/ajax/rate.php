<?php
include '../connection.inc.php';
$rate_id =  $_POST['rate_data'];
$programcatagery =  $_POST['program'];
//$program_id ="MCA2020";
//$program = "SELECT * FROM rate WHERE programcatagery='$programcatagery' AND   ExaminerWork ='$rate_id';";
  
$program= "SELECT * FROM rate WHERE  trim(programcatagery)='$programcatagery'AND trim(ExaminerWork)='$rate_id' ;";
$query = mysqli_query($conn, $program);
// $output="";

while ($p1 = mysqli_fetch_assoc($query)) {
    $output .= '<option value="' . $p1['rate'] . '">' . $p1['rate'] .'</option>';
}
echo $output;