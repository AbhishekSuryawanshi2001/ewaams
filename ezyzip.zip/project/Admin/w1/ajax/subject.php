<?php
include '../connection.inc.php';

$Exam_id =  $_POST['Exam_data'];

$program_id =  $_POST['program'];

//$Exam_id = 'SEMISTER_1';

//$program_id = 'MCA2020';


$sql= "SELECT * FROM course_subject WHERE  trim(programcode)='$program_id'AND trim(Exam)='$Exam_id' ;";
echo $sql;
$query = mysqli_query($conn, $sql);


$output = '<option value="">Select Subject</option>';
while ($c1 = mysqli_fetch_assoc($query)) {
    $output .= '<option value="' . $c1['Course_Subject_code'] . '">' . $c1['Course_Subject_code'] . ':'. $c1['Course_Subject_name'] .'</option>';
}
echo $output;
