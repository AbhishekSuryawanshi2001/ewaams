
<?php
	include_once('../connection.php');

	if(isset($_POST['add'])){
	    $id = $_POST['id'];
        $Quntity = $_POST['Quntity'];
        $rateWork = $_POST['rateWork'];
        $amount=$Quntity*$rateWork;
        $ExaminerWork = $_POST['ExaminerWork'];

		$ExaminerWork1="Answer_Book_Valuation";
		//$tempWork="Answer Book Valuation"; ($amount1<100)&&
		if ((trim($ExaminerWork)==$ExaminerWork1)&&($amount1<100))
		   	
	       $amount=100;
	      
		 else
          
		   $amount=$amount1;
	$sql=" UPDATE workallotement SET 
	  Quntity='$Quntity',amount='$amount' WHERE id = '$id'";

if($sql){

	echo"<script> alert('You Have Successfull inserted the Examiner Allotment') </script>";
	
	echo"<script> document location='index.php'; </script>";
				}
				else{
					echo"<script> alert('Somthing went wrong to Add  Examiner Allotment') </script>";
				}
		if($conn->query($sql)){
	
		}
		
		else{
			
		}
	}
	else{
		
	}

	header('location: index.php');
?>