<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    
    session_unset();
    session_write_close();
    $url = "./Admin/Allo/index.php";
    header("Location: $url");
}

?>
<?php
	include_once('../connection.php');
$country = "SELECT * FROM program";
$county_qry = mysqli_query($conn, $country);
include 'include_common/header.php' ?>
 <form action="addAllo.php" method="POST"  name="Allocation" style="background-color: black;">
<div class="d-flex justify-content-center align-items-center">
    <div class="container my-5">
        <h1 class="text-center my-5" style="color: pink;"> <b>Exam Work Allotment </b></h1>
        <center>
        <div class="card">
            <div class="card-body">
                <div class="col-md-4">
                    <select class="form-select" id="programcode" name="programcode" required>
                    <option value="">Select Program</option>
                        <?php while ($row = mysqli_fetch_assoc($county_qry)) : ?>
                            <option value="<?php echo $row['programcode']; ?>"> <?php echo $row['programname']; ?> </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <strong>Selected Program Catagery</strong>
                <div class="col-md-4">
                    <select class="form-select" id="programcatagery" name='programcatagery' required>
                     
                    </select>
                </div>
                <strong>Select  SEM</strong>
                <div class="col-md-4">
                    <select class="form-select" id="Exam" name='Exam' required>
                    <option selected disabled>Select Sem</option>
                    </select>
                </div>
                <strong>Select  Subject</strong>
                <div class="col-md-4">
                    <select class="form-select" id="Course_Subject_code" name="Course_Subject_code" required>
                        <option selected disabled>Select Subject</option>
                    </select>
                </div>

                
    <strong>Select  Examinr</strong>
           
           <div class="col-md-4">
               <select name="fullname" class="form-select" id="fullname" required>
                   <option value="">Select Examiner</option>
                   <?php 
                   $connect = new PDO("mysql:host=localhost;dbname=ewaams", "root", "");

                  $query = "SELECT fullname,phone
                  FROM  members ";
                   
                   $result = $connect->query($query);
                   foreach($result as $row)
                   {
                       echo '<option value="'.$row["fullname"].' ">'.$row["fullname"].''.$row["phone"].'</option>';
                   }
                   ?>  
               </select>
           </div>
           <strong>Select Session</strong>           
            <div class="col-md-4">
                <select name="Examsession" class="form-select" id="Exam" Required>
                    <option value="">Select Session</option>
                  <option value="SUMMER">SUMMER</option> 
                    <option value="WINTER">WINTER</option>  
                </select>
            </div>


            <strong> SELECT EXAM YEAR</strong>
           
            
           <div class="col-md-4">
               <select name="ExamYear" class="form-select" id="ExamYear" Required>
                   <option value="">SELECT YEAR</option>
                 <option value="2023">2023</option> 
                   <option value="2024">2024</option> 
                   <option value="2025">2025</option>
                   <option value="2026">2026</option> 
                   <option value="2027">2027</option> 
                   <option value="2028">2028</option>
                   <option value="2029">2029</option> 
                   <option value="2030">2030</option>
               </select>
           </div>


           <strong>SELECT EXAM WORK</strong>

           
        
<div class="col-md-4">
   
    <select name="ExaminerWork" class="form-select" id="ExaminerWork" required>
   <option value="">Select Exam Work</option>
   <?php 
   $connect = new PDO("mysql:host=localhost;dbname=ewaams", "root", "");

  $query = "SELECT ExaminerWork
  FROM  examremu ";
   
   $result = $connect->query($query);
   foreach($result as $row)
   {
       echo '<option value="'.$row["ExaminerWork"].' ">'.$row["ExaminerWork"].'</option>';
   }
   ?>  
</select>
</div>



               <strong>SELECTED RATE</strong>

        
               <div class="col-md-4">
             <select class="form-select" id="rateWork" name='rateWork'>
     
              </select>
                   </div>

<strong>Enter Quantity Of Set/Student</strong>
           
            
           <div class="col-md-4">
               <input type="number" name="Quntity"  placeholder="Enter a Quantity Of Sets/shift Or Students" class="form-control" id="Quntity" required >
                 
           </div>
           
         


<strong>Enter a Examiner  Working  Start Date </strong>
           
           
           <div class="col-md-4">
               <input type="date" name="startDate" class="form-select" id="startDate" Required>
                 
           </div>

<strong>Enter a Examiner  Working  Last Date </strong>
           
       
           <div class="col-md-4">
               <input type="date" name="lastDate" class="form-select" id="lastDate" Required>
                 
           </div>
         <!--  <strong> Enter Date Of Allocation</strong>  _----->
       
         <div class="col-md-4">
               <input type="text"  name="PayStatus" class="form-control" id="PayStatus" value="NO"  hidden >
                 
           </div>
           <div class="col-md-4">
               <input type="text"  name="EntryDate" class="form-control" id="date"  hidden >
                 
           </div>
     <br>      <br>           <div class="col-md-8">
 <button class="btn btn-primary" name="add">
                            Allocation</button>
<input type="reset" class="btn btn-primary">
            </div>
            </center>
            </form>
        </div>
    </div>
</div>

<?php include 'include_common/footer.php' ?>

<script>
    // County State

    $('#programcode').on('change', function() {
        var program_id = this.value;
      //console.log(program_id)
        $.ajax({
            url: 'ajax/sem.php',
            type: "POST",
            data: {
                program_data: program_id
            },
            success: function(result) {
                $('#Exam').html(result);
                // console.log(result);
            }
        })
    });
    //select   catageryof program
    $('#programcode').on('change', function() {
        var program_id = this.value;
        // console.log(c_id);
        $.ajax({
            url: 'ajax/cat.php',
            type: "POST",
            data: {
                program_data: program_id
            },
            success: function(result) {
                $('#programcatagery').html(result);
                // console.log(result);
            }
        })
    });
// select Subject


$('#Exam').on('change', function() {
        var Exam_id = this.value;
        var programcode=$("#programcode").val();
        
        //console.log(Exam_id);
       // console.log('Abhi');
     //console.log(programcode);
    
     $.ajax({
            url: 'ajax/subject.php',
            type: "POST",
            data: {
                Exam_data: Exam_id,
                program:programcode    
            },
         
            success: function(result) {
                $('#Course_Subject_code').html(result);
                // console.log(result);
            }
        })
    }); 


 ///work

    $('#ExaminerWork').on('change', function() {
        var rate_id = this.value;
        var programcatagery=$("#programcatagery").val();
    console.log(rate_id);
    console.log('Abhishek');
    console.log(programcatagery);
        // console.log(Exam_id);
        $.ajax({
            url: 'ajax/rate.php',
            type: "POST",
            data: {
                rate_data: rate_id,
                program:programcatagery
            },
            success: function(result) {
                $('#rateWork').html(result);
                // console.log(result);
            }
        })
    }); 


</script>