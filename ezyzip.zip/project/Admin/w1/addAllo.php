<?php
	include_once('../connection.php');
	if(isset($_POST['add'])){
	    $fullname = $_POST['fullname'];
		$programcode = $_POST['programcode'];
		$Course_Subject_code = $_POST['Course_Subject_code'];
	    $Exam = $_POST['Exam'];
		$Examsession = $_POST['Examsession'];
		$ExaminerWork = $_POST['ExaminerWork'];
		$Quntity = $_POST['Quntity'];
		$ExamYear = $_POST['ExamYear'];
		$startDate = $_POST['startDate'];
		$lastDate = $_POST['lastDate'];
		$rateWork = $_POST['rateWork'];
		$PayStatus=$_POST['PayStatus'];
		$amount1=$Quntity*$rateWork;
		//$tempAmount=100;
		$ExaminerWork1="Answer_Book_Valuation";
		//$tempWork="Answer Book Valuation"; ($amount1<100)&&
		if ((trim($ExaminerWork)==$ExaminerWork1)&&($amount1<100))
		   	
	       $amount=100;
	      
		 else
          
		   $amount=$amount1;
		   


	//($ExaminerWork==$ExaminerWork1)?$amount=100:$amount=$amount1;

     $sql = "INSERT INTO workallotement (fullname,programcode,Course_Subject_code,Exam,Examsession,
	 ExaminerWork,ExamYear,Quntity,startDate,lastDate,rateWork,amount,PayStatus ) VALUES 
	('$fullname','$programcode','$Course_Subject_code','$Exam','$Examsession',
	'$ExaminerWork','$ExamYear','$Quntity','$startDate','$lastDate','$rateWork','$amount','$PayStatus' )";

if($sql){

	echo"<script> alert('You Have Successfull inserted the Examiner Allotment') </script>";
	
	echo"<script> document location='index.php'; </script>";
				}
				else{
					echo"<script> alert('Somthing went wrong to Add  Examiner Allotment') </script>";
				}
		if($conn->query($sql)){
		}
		else{	
		}
	}
	else{	
	}
	header('location: index.php');
?>