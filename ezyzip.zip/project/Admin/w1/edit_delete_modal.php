<!-- Edit -->

<div class="modal fade" id="edit_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Edit Allotment</h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="edit.php">
				<input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
				<div class="row form-group">
					<div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="fullname" value="<?php echo $row['fullname']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="programcode" value="<?php echo $row['programcode']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Exam" value="<?php echo $row['Exam']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Course_Subject_code" value="<?php echo $row['Course_Subject_code']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="ExaminerWork" value="<?php echo $row['ExaminerWork']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Examsession" value="<?php echo $row['Examsession']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="ExamYear" value="<?php echo $row['ExamYear']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="Quntity" value="<?php echo $row['Quntity']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="rateWork" value="<?php echo $row['rateWork']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="startDate" value="<?php echo $row['startDate']; ?>">
					</div>
                    <div class="col-sm-2">
						<label class="control-label modal-label">Work:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" name="lastDate" value="<?php echo $row['lastDate']; ?>">
					</div>




				</div>
				
				
            </div>
			</div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="edit" class="btn btn-success"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>

        </div>
    </div>
</div>

<!-- Delete -->
<div class="modal fade" id="delete_<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Delete Rate</h4></center>
            </div>
            <div class="modal-body">
            	<p class="text-center">Are you sure you want to Delete</p>
				<h2 class="text-center"><?php echo $row['id'].' '.$row['ExaminerWork']; ?></h2>
			</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Yes</a>
            </div>

        </div>
    </div>
</div>
<!------ Allo---->
<div class="modal fade" id="Allo_<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Allotment Configration </h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="payamount.php">
			<input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
				<div class="row form-group">
            
               <div class="col-sm-15">
                                         <label class="control-label modal-label">The Aamount is Paid Then Click Yes </label>
                                    </div> 

                                               <div class="col-sm-2">
                                         <label class="control-label modal-label">Yes</label>
                                    </div>
                          <div class="col-sm-2">
                             <input type="radio" class="form-control" name="PayStatus" id="Yes" value="YES">
                                  
                                                                              </div>

                                               <div class="col-sm-2">
                                         <label class="control-label modal-label">NO</label>
                                    </div>
                          <div class="col-sm-2">
                             <input type="radio" class="form-control" name="PayStatus"id="NO" value="" checked >
                                  
                                                                              </div>

				</div>
                <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="add" class="btn btn-success"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>


            </div>
			</div>


		
        

        </div>
    </div>
</div>


<!-- Return--->
<div class="modal fade" id="Return_<?php echo $row['id'];?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel">Allotment Configration </h4></center>
            </div>
            <div class="modal-body">
			<div class="container-fluid">
			<form method="POST" action="Return.php">
			<input type="hidden" class="form-control" name="id" value="<?php echo $row['id']; ?>">
				<div class="row form-group">
            
            
				<div class="col-sm-4">
						<label class="control-label modal-label">Alloted Quntity:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" readonly class="form-control" value="<?php echo $row['Quntity']; ?>">
					</div>
                    <div class="col-sm-4">
						<label class="control-label modal-label">Rates:</label>
					</div>
					<div class="col-sm-10">
						<input type="text" class="form-control" readonly name="rateWork" value="<?php echo $row['rateWork']; ?>">
					</div>
					<div class="col-sm-4">
						<label class="control-label modal-label">Return Quntity:</label>
					</div>
					<div class="col-sm-10">
						<input type="number" class="form-control" name="Quntity">
					</div>                   
					<div class="col-sm-10">
						<input type="hidden"  class="form-control" name="ExaminerWork" value="<?php echo $row['ExaminerWork']; ?>">
					</div>
                    <div class="col-sm-2">
				</div>
                <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <button type="submit" name="add" class="btn btn-success"><span class="glyphicon glyphicon-check"></span> Update</a>
			</form>
            </div>


            </div>
			</div>


		
        

        </div>
    </div>
</div>