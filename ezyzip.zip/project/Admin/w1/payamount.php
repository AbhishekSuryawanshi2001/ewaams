
<?php
	include_once('../connection.php');

	if(isset($_POST['add'])){
	    $id = $_POST['id'];
		$PayStatus = $_POST['PayStatus'];
		
	
	$sql=" UPDATE workallotement SET 
	PayStatus='$PayStatus' WHERE id = '$id'";

if($sql){

	echo"<script> alert('You Have Successfull inserted the Examiner Allotment') </script>";
	
	echo"<script> document location='index.php'; </script>";
				}
				else{
					echo"<script> alert('Somthing went wrong to Add  Examiner Allotment') </script>";
				}
		if($conn->query($sql)){


		
		}
	
		
		else{
			
		}
	}
	else{
		
	}

	header('location: index.php');
?>