<?php
	session_start();
	include_once('../connection.php');

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$ExaminerWork = $_POST['ExaminerWork'];
		
		//$sql = "UPDATE program SET programcode = '$programcode', programname = '$programname', programcatagery = '$programcatagery', totalnosemister = '$totalnosemister',totalstudent='$totalstudent',programduaration='$programduaration'  WHERE id = '$id'";
           
		$sql="UPDATE `examremu` SET ExaminerWork='$ExaminerWork' WHERE id = '$id'";
		//use for MySQLi OOP


		//$sql="UPDATE `program` SET `programcode` = '$programcode',`programname` = '$programname',`programcatagery` 
		//= '$programcatagery',`totalnosemister` = '$totalnosemister',`programduaration` = '$programduaration' WHERE `program`.`id` = &id;";
		if($conn->query($sql)){
		echo "Member updated successfully";
		}
		
		else{
			echo"Something went wrong in updating member";
		}
	}
	else{
	echo"Select member to edit first";
	}

	header('location: index.php');

?>