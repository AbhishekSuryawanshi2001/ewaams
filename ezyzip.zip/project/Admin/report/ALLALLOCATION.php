<?php
	function generateRow(){
		$contents = '';
		include_once('connection.php');
		$sql = "SELECT * FROM workallotement";

		//use for MySQLi OOP
		$query = $conn->query($sql);
		while($row = $query->fetch_assoc()){
			$contents .= "
			<tr>
			
			<td>".$row['Aid']."</td>
			<td>".$row['fullname']."</td>
			
			<td>".$row['programcode'].":".$row['Course_Subject_code'].":
			".$row['Exam']." </td> <td>".$row['Examsession'].":".$row['ExamYear']."</td>
			
			
			
			
	
			
			<td>".$row['ExaminerWork']."</td>
			
			<td>".$row['Quntity']."</td>
			<td>".$row['rateWork']."</td>
			<td>".$row['startDate']."".$row['lastDate']."</td>
			
            
				<td>".$row['amount']."</td>
			
			</tr>
			";
		}
		
		

		return $contents;
	}

	require_once('tcpdf/tcpdf.php');
    $pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetTitle("All_Examiner_Work_Allocation  PDF ");
    $pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
    $pdf->SetDefaultMonospacedFont('helvetica');
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
    $pdf->SetMargins(PDF_MARGIN_LEFT, '0', PDF_MARGIN_RIGHT ,'0');
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    $pdf->SetAutoPageBreak(TRUE, 10);
    $pdf->SetFont('helvetica', '', 11);
    $pdf->AddPage();
    $content = '';
    $content .= '
      	<h2 align="center">Examiner WorkA Allocation INFORMATION</h2>
      	<h4>Work Allocation Table</h4>
      	<table border="1" cellspacing="0" cellpadding="3" width="100%">
           <tr>
    
		   <th>Aid</th>
		   <th> Name</th>
		   <th>Exam Name</th>
		   <th>ExaminerWork</th>
		   
		   <th>qut</th>
		   <th>rate</th>
		   <th>start/lastDate</th>
		 

			   <th>Amount</th>
           </tr>
      ';
			 
    $content .= generateRow();
    $content .= '</table>';
    $pdf->writeHTML($content);
    $pdf->Output('Examiner_Work_Allocation.pdf', 'I');


?>
