<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
   
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>

<!DOCTYPE html>
<html lang="en">
    <html>
    <head>
  
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Bootstrap CSS -->
        <link href="library/bootstrap-5/bootstrap.min.css" rel="stylesheet" />
        <script src="library/bootstrap-5/bootstrap.bundle.min.js"></script>
        <script src="library/dselect.js"></script>
        <style>
    input{
        counter-reset: pink;
        font-size: larger;
        font-family: Verdana, Geneva, Tahoma, sans-serif;
        text-size-adjust: auto;

    }
    fieldset{

        text-decoration: none;
        text-shadow: 0cm;
        text-transform: uppercase;
        overflow: hidden;
         color: red;
        box-shadow: 0cqb;
        border-color: rgb(165, 165, 22);
        background-color: azure;
    }
    body{
margin: 0;
padding: 0;
background-color: black;
    }
    h1{
 background-color: antiquewhite;
text-transform: uppercase;
color: black;
text-decoration:saddlebrown;
    }

</style>
        <title>Examiner Work  Allocation</title>
    </head>
    <body>
   
   <hr>
    <center> <h1> Examiner Work  Allocation </h1></center>
   
    <hr>

    <div class="container">
    <fieldset>
       <center>
    <form method="POST" action="Alloprogramvise.php"  name="proSelect">
   
   
              <br>
          <h2><strong>Select Program</strong> </h2> 
          <br><br>
          
                <div class="col-md-4">
                    <select name="programcode" class="form-select" id="programcode" Required>
                        <option value="">Select Program</option>
                        <?php 
                        $connect = new PDO("mysql:host=localhost;dbname=w1examiner", "root", "");

                        $query = "SELECT * FROM program 
                            ";
                        
                        $result = $connect->query($query);
                        foreach($result as $row)
                        {
                            echo '<option value="'.$row["programcode"].'">'.$row["programcode"].':'.$row["programname"].':'.$row["programcatagery"].'</option>';
                        
                            $programcatagery ='.$row["programcatagery"].';
                            
                        }
                    
                        ?>  
                    </select>
                </div>
                      <br>
                                
                    
                      <br>
                      <br><br> 
                    
             
 <div class="col-md-8">
 <button class="btn btn-primary" name="add" >
                            Allocation</button>

                    
<br>
<hr>         <br>
                      <br>
                      <br><br>
                      <br>
                      <br>
                      <br><br> 
                      <br><br>      
        
        </center>
        </fieldset>
        
        </form>
        </div>
        </div>
                    </body>
                    </html>


                    <script>
                         var select_box_element = document.querySelector('#programcode');
  
  dselect(select_box_element, {
      search: true
  });





                    </script>

         <!--<script src="Allocation.js"></script>

    <script type="text/javascript" src="Allocation.js"></script>
    ->

 
