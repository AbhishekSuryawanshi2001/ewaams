<?php
	function generateRow(){
		$contents = '';
		include_once('connection.php');
		$sql = "SELECT * FROM program";

		//use for MySQLi OOP
		$query = $conn->query($sql);
		while($row = $query->fetch_assoc()){
			$contents .= "
			<tr>
				<td>".$row['id']."</td>
				<td>".$row['programcode']."</td>
				
				<td>".$row['programname']."</td>
				<td>".$row['programcatagery']."</td>
				<td>".$row['totalnosemister']."</td>
				
				<td>".$row['programduaration']."</td>
			
			</tr>
			";
		}
		
		

		return $contents;
	}

	require_once('tcpdf/tcpdf.php');
    $pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetTitle("PROGRAM PDF ");
    $pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
    $pdf->SetDefaultMonospacedFont('helvetica');
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
    $pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);
    $pdf->SetAutoPageBreak(TRUE, 10);
    $pdf->SetFont('helvetica', '', 11);
    $pdf->AddPage();
    $content = '';
    $content .= '
      	<h2 align="center">PROGRAM INFORMATION</h2>
      	<h4>PROGRAM Table</h4>
      	<table border="1" cellspacing="0" cellpadding="3">
           <tr>
        <th width="5%">ID</th>
				<th width="20%">Program Code</th>
				
				<th width="20%">Program Name</th>
				<th width="20%">Program Catagery</th>
				<th width="20%">Total  Semister</th>
				
				<th width="10%">program Duaration</th>
		
           </tr>
      ';
			 
    $content .= generateRow();
    $content .= '</table>';
    $pdf->writeHTML($content);
    $pdf->Output('PROGRAM.pdf', 'I');


?>
