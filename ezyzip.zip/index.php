<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Examiner  Work and Account Manegement System</title>


    <link rel="stylesheet" href="css/swiper-bundle.min.css">

    <link rel="stylesheet" href="css/scrollreveal.min.js">

    
    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
        

    <link rel="stylesheet" href="css/style.css">

</head>
<body>
<!-- Header -->
    <header class="header">
            <nav class="nav container flex">
                    <a href="#" class="logo-content flex">
                        <i class='bx bx-book-open logo-icon'></i>
                        <span class="logo-text">EWAAMS.</span>
                    </a>

                    <div class="menu-content">
                            <ul class="menu-list flex">
                                    <li><a href="#home" class="nav-link active-navlink">home</a></li>
                                    <li><a href="#about" class="nav-link">about</a></li>
                                    <li><a href="#menu" class="nav-link">Top Courses</a></li>
                                    <li><a href="#review" class="nav-link">Top Persan</a></li>
                                    <li><a href="project/" class="nav-link">Login</a></li>
                            </ul>

                            <div class="media-icons flex">
                                    <a href="https://www.facebook.com"><i class='bx bxl-facebook'></i></a>
                                    <a href="https://twitter.com/i/flow/login"><i class='bx bxl-twitter' ></i></a>
                                    <a href="https://www.instagram.com/accounts/login"><i class='bx bxl-instagram-alt' ></i></a>
                
                                    <a href="https://www.youtube.com/login"><i class='bx bxl-youtube'></i></a>
                            </div>

                            <i class='bx bx-x navClose-btn'></i>
                        </div>
                        
                        <div class="contact-content flex">
                            <i class='bx bx-phone phone-icon' ></i>
                            <span class="phone-number">+91-721-2573788|+91-721-2573258</span>
                        </div>

                        <i class='bx bx-menu navOpen-btn'></i>
                </nav>
        
    </header>

<!-- Home Section -->
    <main>
        <section class="home" id="home">
                <div class="home-content">
                        <div class="swiper mySwiper">
                                <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                                <img src="images/home1.jpg" alt="" class="home-img">

                                                <div class="home-details">
                                                        <div class="home-text">
                                                                <h4 class="homeSubtitle">I really love P.G.Department of Computer Science & Technology.</h4>
                                                                <h2 class="homeTitle">Ballam Upassav <br> Aage Badho, Sabse Aage Badho</h2>
                                                        </div>

                                                </div>
                                        </div>

                                        <div class="swiper-slide">
                                                <img src="images/home2.jpg" alt="" class="home-img">

                                                <div class="home-details">
                                                        <div class="home-text">
                                                                <h4 class="homeSubtitle">EWAAMS .</h4>
                                                                <h2 class="homeTitle">Examiner Work And Account Manegement System</h2>
                                                        </div>

                                                        
                                                </div>
                                        </div>

                                        <div class="swiper-slide">
                                                <img src="images/home3.jpg" alt="" class="home-img">

                                                <div class="home-details">
                                                        <div class="home-text">
                                                                <h4 class="homeSubtitle">M.C.A. Department, D.C.P.E., H.V.P.M., Amravati.</h4>
                                                                <h2 class="homeTitle"> Computer Science & <br>Technology </h2>
                                                        </div>

                                                      
                                                </div>
                                        </div>
                                </div>

                                <div class="swiper-button-next swiper-navBtn"></div>
                                <div class="swiper-button-prev swiper-navBtn"></div>
                                <div class="swiper-pagination"></div>
                        </div>
                </div>
        </section>

    
<!-- About Section -->
        <section class="section about" id="about">
                <div class="about-content container">
                        <div class="about-imageContent">
                                <img src="images/padmashri.jpg" alt="" class="about-img">

                                <div class="aboutImg-textBox">
                                        <i class='bx bx-heart heart-icon flex'></i>
                                        <p class="content-description">I really love P.G.Department of Computer Science & Technology . HVP Mandal's Degree College of Physical Education,   Hanuman Vyayam Nagar, Amravati, .</p>
                                </div>
                        </div>

                        <div class="about-details">
                                <div class="about-text">
                                        <h4 class="content-subtitle"><i>Our Degree College of Physical Education,</i></h4>
                                        <h2 class="content-title">We Combine Classics <br> and Modernity</h2>
                                        <p class="content-description">We appreciate your trust greatly. 
                                                Our Student choose us and our Degree because they know we are the best.</p>

                                        <ul class="about-lists flex">
                                                <li class="about-list">HVPM</li>
                                                <li class="about-list dot">DCPE</li>
                                                <li class="about-list"> Department Computer Science & Technology</li>
                                                <li class="about-list dot">Master of Computer Application </li>
                                                <li class="about-list"> </li>
                                        </ul>
                                </div>

                                <div class="about-buttons flex">
                                        <button class="button">About Us</button>
                                        <a href="#" class="about-link flex">
                                                <span class="link-text">see more</span>
                                                <i class='bx bx-right-arrow-alt about-arrowIcon'></i>
                                        </a>
                                </div>
                        </div>

                </div>
        </section>

    
<!-- Menu Section -->
        <section class="section menu" id="menu">
            <div class="menu-container container">
                    <div class="meu-text">
                            <h4 class="section-subtitle"><i>Our Courses</i></h4>
                            <h2 class="section-title">Our Popular Courses</h2>
                            <p class="section-description">
                                Our Courses designed by pro architecture with psychologist to build best place suit you. Our place designed by pro architecture with psychologist to build best place suit you.
                            </p>
                    </div>

                    <div class="menu-content">
                            <div class="menu-items">
                                    <div class="menu-item flex">
                                            <img src="images/deptmca.jpg" alt="" class="menu-img">

                                            <div class="menuItem-details">
                                                    <h4 class="menuItem-topic">M.C.A. Department, D.C.P.E., H.V.P.M., Amravati</h4>
                                                    <p class="menuItem-des">Shree Hanuman Vyayam Prasarak Mandal, Amravati is a voluntary organization established in the year 1914. It was the active center of freedom fighters during the ...</p>
                                            </div>

                                            <div class="menuItem-price flex">
                                                    <span class="discount-price">Addmisions</span>
                                                    <span class="real-price">Open</span>
                                            </div>
                                    </div>
                                    
                                    <div class="menu-item flex">
                                            <img src="images/deptphy.jpg" alt="" class="menu-img">

                                            <div class="menuItem-details">
                                                    <h4 class="menuItem-topic">Degree College of Physical Education</h4>
                                                    <p class="menuItem-des">Degree College of Physical Education is runned by world famous institute Shree Hanuman Vyayam Prasarak Mandal. Mandal is established in 1914 and has ....</p>
                                            </div>

                                            <div class="menuItem-price flex">
                                                    <span class="discount-price">Addmisions</span>
                                                    <span class="real-price">Open</span>
                                            </div>
                                    </div>
                                    <div class="menu-item flex">
                                            <img src="images/deptphy.jpg" alt="" class="menu-img">

                                            <div class="menuItem-details">
                                                    <h4 class="menuItem-topic">Research
                                                        Degree College of Physical Education</h4>
                                                    <p class="menuItem-des">Incubation Committee. Consultancy Policy. Research Projects Conducted by the College. Workshop and Seminars. Student Enrolled for Ph.D. Pre Defence Notice..</p>
                                            </div>

                                            <div class="menuItem-price flex">
                                                    <span class="discount-price">Addmisions</span>
                                                    <span class="real-price">Open</span>
                                            </div>
                                    </div>
                            </div>

                            <div class="time-table">
                                    <span class="time-topic">Catogries Time</span>

                                    <ul class="time-lists">
                                            <li class="time-list flex">
                                                    <span class="open-day"> Sunday</span>
                                                    <span class="open-time">Closed</span>
                                            </li>
                                            <li class="time-list flex">
                                                    <span class="open-day"> Monday</span>
                                                    <span class="open-time">7.00am - 3.00pm</span>
                                            </li>
                                            <li class="time-list flex">
                                                    <span class="open-day"> Tuesday</span>
                                                    <span class="open-time">7.00am - 3.00pm</span>
                                            </li>
                                            <li class="time-list flex">
                                                    <span class="open-day"> Wednesday</span>
                                                    <span class="open-time">7.00am - 3.00pm</span>
                                            </li>
                                            <li class="time-list flex">
                                                    <span class="open-day"> Thursday</span>
                                                    <span class="open-time">7.00am - 3.00pm</span>
                                            </li>
                                            <li class="time-list flex">
                                                    <span class="open-day"> Friday</span>
                                                    <span class="open-time">7.00am - 3.00pm</span>
                                            </li>
                                            <li class="time-list flex">
                                                    <span class="open-day"> Saturday</span>
                                                    <span class="open-time">9.00am - 2.00pm</span>
                                            </li>
                                    </ul>
                            </div>
                    </div>
            </div>
        </section>

    
<!-- Brand Section -->
        <section class="section brand">
            <div class="brand-container container">
                    <h4 class="section-subtitle"><i>'Aage Badho, Sabse Aage Badho'</i></h4>

                    <div class="brand-images">
                            
                            <div class="brand-image">
                                    <img src="images/logo2.jpg" alt="" class="brand-img">
                            </div>
                            <div class="brand-image">
                                    <img src="images/logo3.jpg" alt="" class="brand-img">
                            </div>
                            <div class="brand-image">
                                    <img src="images/logo4.png" alt="" class="brand-img">
                            </div>
                            <div class="brand-image">
                                    <img src="images/logo5.jpg" alt="" class="brand-img">
                            </div>
                            <div class="brand-image">
                                <img src="images/logo2.jpg" alt="" class="brand-img">
                        </div>
                    </div>
            </div>
        </section>

    
<!-- Reviews Section -->
        <section class="section review" id="review">
            <div class="review-container container">
                    <div class="review-text">
                            <h4 class="section-subtitle"><i>Padma Shri  Shri. P.A.Vaidya</i></h4>
                            <h2 class="section-title"> Prabhakar Vaidya</h2>
                            <p class="section-description">Awards	Padma Shri
                                Shiv Chhatrapati State Award
                                State Best Teacher Award
                                LNIPE Best Old Student Award
                                Karmavir Kannamwar Award
                                Dadaji Didolkar Award
                                Paul Harris Fellow International Award
                                Ramchandra Purushottam Ganorkar Smruti Samajik Puraskar
                                Shiv Chhatrapati Jiwan Gaurav Puraskar
                                Krida Jivanvrati Sanman
                                Vidarbha Gaurav Award
                                Sant Gadge Baba Social Work Award
                                Bharat Scouts and Guides Lifetime Achievement Award
                                Vidarbha Bhushan Puraskar
                                Krida Maharshi
                                Jivan Gaurav Lifetime Achievement Award
                                Limca Book Award</p>
                    </div>

                    <div class="tesitmonial swiper mySwiper">
                            <div class="swiper-wrapper">
                                    <div class="testi-content swiper-slide flex">
                                            <img src="images/gensecretory.jpg" alt="" class="review-img">
                                            <p class="review-quote">'Ballam Upassav' was Ambadaspant's moral and 'Aage Badho, Sabse Aage Badho' was his slogan and his son Shri Prabbhakarrao Vaidya and other followers are ...!</p>
                                            <i class='bx bxs-quote-alt-left quote-icon'></i>

                                            <div class="testi-personDetails flex">
                                                    <span class="name"> Prabhakar Vaidya Saheb</span>
                                                    <span class="job">The Honorary Secretary of Hanuman Vyayam Prasarak Mandal,[1] </span>
                                            </div>
                                    </div>
                                    <div class="testi-content swiper-slide flex">
                                            <img src="images/pencipel.jpg" alt="" class="review-img">
                                            <p class="review-quote">Greetings!
                                                Innovation and inclusion being the key values of any institution in a globalized era, educational institutions cannot be an exception. Today, the College stands proud with 50 <sup>+</sup> years of splendid achievements and commitment to the mission through holistic education.!</p>
                                            <i class='bx bxs-quote-alt-left quote-icon'></i>

                                            <div class="testi-personDetails flex">
                                                    <span class="name">Prof Dr. S.P. Deshpande</span>
                                                    <span class="job">Principal,
                                                        HVP Mandal's Degree College of Physical Education,
                                                        Amravati. MS-INDIA 444605</span>
                                            </div>
                                    </div>
                                    <div class="testi-content swiper-slide flex">
                                            <img src="images/hod.jpg" alt="" class="review-img">
                                            <p class="review-quote">The P.G. Department of Computer Science & Technology established in the year 1995-1996 with the permission given by AICTE New Delhi for starting MCA programme. This Department is attached to the Degree College of Physical Education, which is recognized by UGC under section 2(f) and 12B and is accredited by NAAC with ‘B’ grade. The UGC granted autonomous status to this college from 2007, this is the only college of its kind having this status in the whole Country.!</p>
                                            <i class='bx bxs-quote-alt-left quote-icon'></i>

                                            <div class="testi-personDetails flex">
                                                    <span class="name"> Prof Dr.Sanjay E. Yede</span>
                                                    <span class="job"> The College is successfully running the AICTE recognized course, Master in Computer Application (M.C.A) since 1995 onwards</span>
                                            </div>
                                    </div>
                                </div>
                                <div class="swiper-button-next swiper-navBtn"></div>
                                <div class="swiper-button-prev swiper-navBtn"></div>
                                <div class="swiper-pagination"></div>
                    </div>
            </div>
        </section>

    
<!-- Newsletter Section -->
        <section class="section newsletter">
            <div class="newletter-container container">
                <a href="#" class="logo-content flex">
                        <i class='bx bx-book-open logo-icon'></i>
                        <span class="logo-text">EAMS.</span>
                    </a>

                    <p class="section-description"><H1>About H. V. P. Mandal </H1><br>

                        Shree H. V. P. Mandal, Amravati, established in 1914 and is registered under Bombay Public Trust Act 1950 and Societies Registration Act 1860. It is a Voluntary, Social, Non-Political & Secular Institute, managed with democratic principles & practices. It is founded by Vaidya Brothers namely Shri. Ambadaspant & Shri. Anant Krishna Vaidya with their colleagues, freedom fighters on the broader principles of equality, fraternity & social justice. Honorable National leaders like Mahatma Gandhi, Subhash Chandra Bose, Dr. Rajendra Prasad visited & blessed this organization. Martyrs Rajguru & D.S. Deshpande were the two illustrious students of this institution. To standardize and popularize India’s traditional system of physical culture and develop sport and allied science and employ them strategically towards welfare of the masses, Institute has timely organized various tours in India (J&K, Delhi, Calcutta, Ahmadabad, Lucknow, Amritsar, Panji, etc.) as well as abroad (U.S.A., U.S.S.R., Finland, France, Japan, U.K., Germany, Argentina, Brazil, Poland, Denmark, Lithuania, Sri lanka, Indonesia, etc.) for Propagation of Indian Traditional sport since year 1928. The work of the Mandal has been appreciated by many organizations and received honours in the form of awards and certificates from time to time.German Dictator Adolph Hitler has also honored this Institute with a medal for its breath taking demonstrations in Berlin Olympics Games in the year 1936. After Independence, to propagate traditional Indian Sports and Yoga, the Mandal concentrated its efforts on the training of teachers in Physical Education and Yoga, and gradually diversified its activities to the field of Ayurvedic medicine, tribal and school education and Engineering and Technology. The Mandal is the recipient of prestigious “Aadivasi Seva Sanstha Puraskar – 1997 of Maharashtra Government” for its work in tribal regions and the “State Government Award -2002” for Educational institutions ..</p>

                    <div class="newsletter-inputBox">
                            <input type="email" placeholder="HVPMDCPM@gmail.com" class="newletter-input">
                            <button class="button newsletter-button">Subscribe</button>
                    </div>

                    <div class="newsletter media-icons flex">
                        <a href="https://www.facebook.com/hvpmandal/"><i class='bx bxl-facebook'></i></a>
                        <a href="https://twitter.com/1121Coet/status/1305717281800871936"><i class='bx bxl-twitter' ></i></a>
                        <a href="https://www.instagram.com/hvpmofficial/?ig..."><i class='bx bxl-instagram-alt' ></i></a>
                        <a href="https://www.youtube.com/channel/UCqMOWaW4QZCKkwcnGl_eD6g"><i class='bx bxl-youtube'></i></a>
                </div>
            </div>
        </section>
        
    
<!-- Footer Section -->
        <footer class="section footer">
            <div class="footer-container container">
                    <div class="footer-content">
                        <a href="#" class="logo-content flex">
                                <i class='bx bx-book-open logo-icon'></i>
                                <span class="logo-text">EAMS.</span>
                            </a>

                            <p class="content-description"> Good luck exam wishes <br>
                                “Remember, the harder you study, the luckier you'll get!” “Don't stress, just do your best and let the results speak for themselves.” “Good luck with your exam today. You have all the knowledge you need to succeed.”.</p>

                            <div class="footer-location flex">
                                <i class='bx bx-map map-icon'></i>
                                
                                <div class="location-text">
                                        
                                        Address:Hanuman Vyayam Nagar, Amravati, Maharashtra Pin Code:INDIA, 444605
                                </div>
                            </div>
                    </div>

                    <div class="footer-linkContent">
                            <ul class="footer-links">
                                    <h4 class="footerLinks-title">Facility</h4>

                                    <li><a href="#" class="footer-link">MCA</a></li>
                                    <li><a href="#" class="footer-link">MSC</a></li>
                                    <li><a href="#" class="footer-link">BCA</a></li>
                                    <li><a href="#" class="footer-link">BSC</a></li>
                                    <li><a href="#" class="footer-link">BBA</a></li>
                            </ul>
                            <ul class="footer-links">
                                    <h4 class="footerLinks-title">Faculty</h4>

                                    <li><a href="#" class="footer-link">EAMS</a></li>
                                    <li><a href="#" class="footer-link">Degree</a></li>
                                    <li><a href="#" class="footer-link">Departments</a></li>
                            </ul>
                            <ul class="footer-links">
                                    <h4 class="footerLinks-title">Support</h4>

                                    <li><a href="#" class="footer-link">About Us</a></li>
                                    <li><a href="#" class="footer-link">FAQs</a></li>
                                    <li><a href="#" class="footer-link">Private Policy</a></li>
                                    <li><a href="#" class="footer-link">Help Us</a></li>
                            </ul>
                    </div>
            </div>
            <div class="footer-copyRight">&#169; Abhishek|9604679432. All rigths reserved</div>
        </footer>

<!-- Scroll Up -->
        <a href="#home" class="scrollUp-btn flex">
                <i class='bx bx-up-arrow-alt scrollUp-icon'></i>
        </a>

</main>

<!-- Swiper JS -->
<script src="js/swiper-bundle.min.js"></script>

<!-- Scroll Reveal -->
<script src="js/scrollreveal.js"></script>

<!-- JavaScript -->
    <script src="js/script.js"></script>
</body>
</html>