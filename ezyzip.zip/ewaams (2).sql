-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2023 at 09:37 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ewaams`
--

-- --------------------------------------------------------

--
-- Table structure for table `course_subject`
--

CREATE TABLE `course_subject` (
  `id` int(11) NOT NULL,
  `Course_Subject_code` varchar(255) NOT NULL,
  `Course_Subject_name` varchar(255) NOT NULL,
  `programcode` varchar(255) NOT NULL,
  `Course_Subject_shotname` varchar(50) NOT NULL,
  `Course_Subject_type` varchar(50) NOT NULL,
  `totalunit` varchar(10) NOT NULL,
  `minimark` varchar(10) NOT NULL,
  `Exam` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course_subject`
--

INSERT INTO `course_subject` (`id`, `Course_Subject_code`, `Course_Subject_name`, `programcode`, `Course_Subject_shotname`, `Course_Subject_type`, `totalunit`, `minimark`, `Exam`) VALUES
(1, '20MCA103', 'DATA STRUCTURES & ALGORITHMS', 'MCA2020', 'DSA', 'CORE COURSE', '5', '70', 'SEMISTER_1'),
(2, '20MCA104', 'DATA BASEMANAGEMENT SYSTEM', 'MCA2020', 'DBMS', 'GENERIC', '5', '70', 'SEMISTER_1'),
(3, '20MCA105', 'SOFT SKILL DEVELOPMENT', 'MCA2020', 'SSD', 'ABILITY ENHANCEMENT', '5', '50', 'SEMISTER_1'),
(4, '20MCA102', 'PROBLEM  SOLVING AND PROGRAMMING METHODOLOGY', 'MCA2020', 'PSPM', 'CORE', '5', '70', 'SEMISTER_1'),
(5, '20MCA101', 'COMPUTER ORGANIZATION AND COMMUNICATION TECHNOLOGY ', 'MCA2020', 'COCT', 'CORE', '5', '70', 'SEMISTER_1'),
(6, '20MCA201', 'OPERATING SYSTEM CONCEPT ', 'MCA2020', 'OS', 'CORE COURSE', '5', '70', 'SEMISTER_2'),
(7, '20MCA202', 'WEB PROGRAMMING', 'MCA2020', 'WP', 'CORE COURSE', '5', '70', 'SEMISTER_2'),
(8, '20MCA203', 'ADVANCE JAVA', 'MCA2020', 'AJ', 'CORE COURSE', '5', '70', 'SEMISTER_2'),
(9, '20MCA204', 'DATABASE ADMINISTRATION ', 'MCA2020', 'DBA', 'ELECTIVE', '5', '70', 'SEMISTER_2'),
(10, '20MCA204', 'COMPUTER NETWORK DESIGN AND ADMINISTRATION', 'MCA2020', 'CN', 'ELECTIVE', '5', '70', 'SEMISTER_2'),
(11, '20MCA204', 'AI & ROBOTICS PROGRAMMING', 'MCA2020', 'AI & RP', 'ELECTIVE', '5', '70', 'SEMISTER_2'),
(12, '20MCA301', 'SOFTWARE DESIGN AND PROJECT MANAGEMENT', 'MCA2020', 'SDPM', 'CORE COURSE', '5', '70', 'SEMISTER_3'),
(13, '20MCA302', 'DATA SCIENCE', 'MCA2020', 'DS', 'CORE COURSE', '5', '70', 'SEMISTER_3'),
(14, '20MCA303', 'DATA WAREHOUSE AND DATA CLOUD', 'MCA2020', 'DWAC', 'ELECTIVE THEORY 2', '5', '70', 'SEMISTER_3'),
(15, '20MCA303', 'INTERNET OF THE THINGS', 'MCA2020', 'IOT', 'ELECTIVE THEORY 2', '5', '70', 'SEMISTER_3'),
(16, '20MCA204', 'SOFTWARE TESTING ', 'MCA2020', 'ST', 'ELECTIVE THEORY 3', '5', '70', 'SEMISTER_3'),
(17, '20MCA304', 'FULL STACK DEVELOPMENT', 'MCA2020', 'FSD', 'ELECTIVE THEORY 3', '5', '70', 'SEMISTER_3'),
(18, '20MCA304', 'MOBILE APPLICATION DEVELOPMENT ', 'MCA2020', 'MAD', 'ELECTIVE ', '5', '70', 'SEMISTER_3'),
(19, '20MCA401', 'INDUSTRY PROJECT / INTERNSHIP /STARTUP ', 'MCA2020', 'ITES', 'SKILL COURSE', '00', '00', 'SEMISTER_4'),
(20, '20MCA402', 'SEMINAR /PRESENTATION', 'MCA2020', 'SP', 'SKILL COURSE', '00', '00', 'SEMISTER_4'),
(22, '22MSC101', 'PROGEAMMING METHODOLGY AND OOP,S USING JAVA', 'MSC2022', 'PMOJ', 'CORE COURSE THEORY', '5', '70', 'SEMISTER_1'),
(23, '22MSC102', 'DATA STRUCTURE AND FILE DESIGN', 'MSC2022', 'DSFD', 'CORE  COURSE THEORY', '5', '70', 'SEMISTER_1'),
(24, '22MSC103', 'COMPUTER ORGANIZATION AND OPRATING SYSTEM', 'MSC2022', 'COOS', 'CORE COURSE  THEORY', '5', '70', 'SEMISTER_1'),
(25, '22MSC104', 'ELEECTIVE - 1 : MATHMATICAL FOUNDATION', 'MSC2022', 'ELE1:MF', 'DISIPLINE SPECIFIC THEORY', '5', '70', 'SEMISTER_1');

-- --------------------------------------------------------

--
-- Table structure for table `examremu`
--

CREATE TABLE `examremu` (
  `id` int(11) NOT NULL,
  `ExaminerWork` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `examremu`
--

INSERT INTO `examremu` (`id`, `ExaminerWork`) VALUES
(1, 'Paper Setting'),
(2, 'Answer_Book_Valuation'),
(4, 'Practial'),
(5, 'Seminar '),
(6, 'Project'),
(7, 'Dissertation / Viva'),
(8, 'Local Conveyance'),
(9, 'Examination Officer'),
(10, 'Invigilator'),
(11, 'Barcode Supervisor'),
(12, 'Clerk'),
(13, 'Peon / Packers'),
(14, 'Waterman');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `Affi` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(10) NOT NULL,
  `ExaminerExperience` varchar(255) NOT NULL,
  `ExaminerExpertise` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `internal_eaxtranal` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `fullname`, `Affi`, `address`, `phone`, `ExaminerExperience`, `ExaminerExpertise`, `email`, `internal_eaxtranal`) VALUES
(1, 'Pooja Rajesh Anasane', 'DCPE HVPM', 'Ravi Nagar Amravti', '9158594599', 'Oprating System', '3 Year', 'poojarajeshanasane@gmail.com', 'internal'),
(2, 'Abhishek Pundlik Suryawanshi', 'hvpm', 'umarkhed', '9604679432', 'ASP', '4 Year', 'suryawanshiabhishek099@gmail.com', 'internal');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `id` int(11) NOT NULL,
  `programcode` varchar(25) NOT NULL,
  `programname` varchar(55) NOT NULL,
  `programcatagery` varchar(255) NOT NULL,
  `totalnosemister` varchar(255) NOT NULL,
  `programduaration` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`id`, `programcode`, `programname`, `programcatagery`, `totalnosemister`, `programduaration`) VALUES
(1, 'MCA2020', 'MASTER OF COMPUTER APPLICATION', 'POST_GRADUATION', '4_SEMESTERE', '2_YEAR'),
(2, 'MSC2022', 'MASTER IN COMPUTER SICENCE', 'POST_GRADUATION', '4_SEMESTERE', '2_YEAR');

-- --------------------------------------------------------

--
-- Table structure for table `rate`
--

CREATE TABLE `rate` (
  `id` int(11) NOT NULL,
  `ExaminerWork` varchar(255) NOT NULL,
  `programcatagery` varchar(25) NOT NULL,
  `quentity` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `years` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rate`
--

INSERT INTO `rate` (`id`, `ExaminerWork`, `programcatagery`, `quentity`, `rate`, `years`) VALUES
(1, 'Paper Setting', 'POST_GRADUATION', 1, 300, '2023'),
(2, 'Paper Setting', 'UNDER_GRADUATION', 1, 300, '2023'),
(3, 'Answer_Book_Valuation', 'UNDER_GRADUATION', 1, 12, '2023'),
(4, 'Answer_Book_Valuation', 'POST_GRADUATION', 1, 15, '2023'),
(7, 'Practial', 'UNDER_GRADUATION', 1, 15, '2023'),
(8, 'Practial', 'POST_GRADUATION', 1, 20, '2023'),
(9, 'Seminar ', 'POST_GRADUATION', 1, 150, '2023'),
(10, 'Project', 'POST_GRADUATION', 1, 150, '2023'),
(11, 'Dissertation / Viva', 'POST_GRADUATION', 1, 100, '2023'),
(12, 'Local Conveyance', 'POST_GRADUATION', 1, 100, '2023'),
(13, 'Local Conveyance', 'UNDER_GRADUATION', 1, 100, '2023'),
(14, 'Examination Officer', 'POST_GRADUATION', 1, 200, '2023'),
(15, 'Examination Officer', 'UNDER_GRADUATION', 1, 200, '2023'),
(16, 'Invigilator', 'POST_GRADUATION', 1, 150, '2023'),
(17, 'Invigilator', 'UNDER_GRADUATION', 1, 150, '2023'),
(18, 'Barcode Supervisor', 'POST_GRADUATION', 1, 150, '2023'),
(19, 'Barcode Supervisor', 'UNDER_GRADUATION', 1, 150, '2023'),
(20, 'Clerk', 'POST_GRADUATION', 1, 100, '2023'),
(21, 'Clerk', 'UNDER_GRADUATION', 1, 100, '2023'),
(22, 'Peon / Packers', 'POST_GRADUATION', 1, 75, '2023'),
(23, 'Peon / Packers', 'UNDER_GRADUATION', 1, 75, '2025'),
(24, 'Waterman', 'POST_GRADUATION', 1, 50, '2023'),
(25, 'Waterman', 'UNDER_GRADUATION', 1, 50, '2023');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`id`, `username`, `password`, `email`, `create_at`) VALUES
(1, 'Abhishek', '$2y$10$TMz1zJGiVeNumoP/uiARPO7nCr6AQ7OY6RW3noVL1a2SAYP8NYRwi', 'suryawanshiabhishek099@gmail.com', '2023-09-14 16:03:12'),
(2, 'HVPM', '$2y$10$7L7gRqnyqPaLXGIzBK6XV.D.tXqb2tEkSMrk5bN.qQK//3H77RdDK', 'HVPM@gmail.com', '2023-09-14 18:19:52');

-- --------------------------------------------------------

--
-- Table structure for table `workallotement`
--

CREATE TABLE `workallotement` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `programcode` varchar(50) NOT NULL,
  `Course_Subject_code` varchar(50) NOT NULL,
  `Exam` varchar(50) NOT NULL,
  `Examsession` varchar(50) NOT NULL,
  `ExaminerWork` varchar(50) NOT NULL,
  `ExamYear` varchar(50) NOT NULL,
  `Quntity` varchar(255) NOT NULL,
  `startDate` varchar(50) NOT NULL,
  `lastDate` varchar(50) NOT NULL,
  `rateWork` varchar(50) NOT NULL,
  `amount` varchar(50) NOT NULL,
  `PayStatus` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `workallotement`
--

INSERT INTO `workallotement` (`id`, `fullname`, `programcode`, `Course_Subject_code`, `Exam`, `Examsession`, `ExaminerWork`, `ExamYear`, `Quntity`, `startDate`, `lastDate`, `rateWork`, `amount`, `PayStatus`) VALUES
(1, 'Pooja Rajesh Anasane ', 'MCA2020', '20MCA103', 'SEMISTER_1', 'SUMMER', 'Answer_Book_Valuation ', '2023', '30', '2023-10-06', '2023-10-06', '15', '450', 'NO_RETURN');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course_subject`
--
ALTER TABLE `course_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `examremu`
--
ALTER TABLE `examremu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `fullname` (`fullname`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rate`
--
ALTER TABLE `rate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workallotement`
--
ALTER TABLE `workallotement`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course_subject`
--
ALTER TABLE `course_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `examremu`
--
ALTER TABLE `examremu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `program`
--
ALTER TABLE `program`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `rate`
--
ALTER TABLE `rate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbl_member`
--
ALTER TABLE `tbl_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `workallotement`
--
ALTER TABLE `workallotement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
